import{i as me,o as Ce}from"./DteLHqF4.js";import{a0 as J,w as s,p as N,s as R,r as $,t as w,o as M,$ as Q,bf as D,ah as S,N as pe,bs as X,bE as W,bA as ke,bF as Y,E as O,b5 as T,u as xe,b2 as ze,Q as p,ad as ye,z as U,P as q,bm as Se,D as V,ao as Pe,ap as Ie,bd as Re,an as G,aV as $e,bK as Oe,aT as Be,bJ as He,V as Ee}from"./O-zoPhqF.js";const Me={closeIconSizeTiny:"12px",closeIconSizeSmall:"12px",closeIconSizeMedium:"14px",closeIconSizeLarge:"14px",closeSizeTiny:"16px",closeSizeSmall:"16px",closeSizeMedium:"18px",closeSizeLarge:"18px",padding:"0 7px",closeMargin:"0 0 0 4px"};function Te(o){const{textColor2:u,primaryColorHover:l,primaryColorPressed:b,primaryColor:t,infoColor:i,successColor:n,warningColor:d,errorColor:h,baseColor:f,borderColor:m,opacityDisabled:g,tagColor:P,closeIconColor:z,closeIconColorHover:y,closeIconColorPressed:r,borderRadiusSmall:c,fontSizeMini:k,fontSizeTiny:e,fontSizeSmall:a,fontSizeMedium:v,heightMini:x,heightTiny:C,heightSmall:B,heightMedium:I,closeColorHover:H,closeColorPressed:_,buttonColor2Hover:j,buttonColor2Pressed:F,fontWeightStrong:E}=o;return Object.assign(Object.assign({},Me),{closeBorderRadius:c,heightTiny:x,heightSmall:C,heightMedium:B,heightLarge:I,borderRadius:c,opacityDisabled:g,fontSizeTiny:k,fontSizeSmall:e,fontSizeMedium:a,fontSizeLarge:v,fontWeightStrong:E,textColorCheckable:u,textColorHoverCheckable:u,textColorPressedCheckable:u,textColorChecked:f,colorCheckable:"#0000",colorHoverCheckable:j,colorPressedCheckable:F,colorChecked:t,colorCheckedHover:l,colorCheckedPressed:b,border:`1px solid ${m}`,textColor:u,color:P,colorBordered:"rgb(250, 250, 252)",closeIconColor:z,closeIconColorHover:y,closeIconColorPressed:r,closeColorHover:H,closeColorPressed:_,borderPrimary:`1px solid ${s(t,{alpha:.3})}`,textColorPrimary:t,colorPrimary:s(t,{alpha:.12}),colorBorderedPrimary:s(t,{alpha:.1}),closeIconColorPrimary:t,closeIconColorHoverPrimary:t,closeIconColorPressedPrimary:t,closeColorHoverPrimary:s(t,{alpha:.12}),closeColorPressedPrimary:s(t,{alpha:.18}),borderInfo:`1px solid ${s(i,{alpha:.3})}`,textColorInfo:i,colorInfo:s(i,{alpha:.12}),colorBorderedInfo:s(i,{alpha:.1}),closeIconColorInfo:i,closeIconColorHoverInfo:i,closeIconColorPressedInfo:i,closeColorHoverInfo:s(i,{alpha:.12}),closeColorPressedInfo:s(i,{alpha:.18}),borderSuccess:`1px solid ${s(n,{alpha:.3})}`,textColorSuccess:n,colorSuccess:s(n,{alpha:.12}),colorBorderedSuccess:s(n,{alpha:.1}),closeIconColorSuccess:n,closeIconColorHoverSuccess:n,closeIconColorPressedSuccess:n,closeColorHoverSuccess:s(n,{alpha:.12}),closeColorPressedSuccess:s(n,{alpha:.18}),borderWarning:`1px solid ${s(d,{alpha:.35})}`,textColorWarning:d,colorWarning:s(d,{alpha:.15}),colorBorderedWarning:s(d,{alpha:.12}),closeIconColorWarning:d,closeIconColorHoverWarning:d,closeIconColorPressedWarning:d,closeColorHoverWarning:s(d,{alpha:.12}),closeColorPressedWarning:s(d,{alpha:.18}),borderError:`1px solid ${s(h,{alpha:.23})}`,textColorError:h,colorError:s(h,{alpha:.1}),colorBorderedError:s(h,{alpha:.08}),closeIconColorError:h,closeIconColorHoverError:h,closeIconColorPressedError:h,closeColorHoverError:s(h,{alpha:.12}),closeColorPressedError:s(h,{alpha:.18})})}const _e={common:J,self:Te},je={color:Object,type:{type:String,default:"default"},round:Boolean,size:String,closable:Boolean,disabled:{type:Boolean,default:void 0}},Fe=N("tag",`
 --n-close-margin: var(--n-close-margin-top) var(--n-close-margin-right) var(--n-close-margin-bottom) var(--n-close-margin-left);
 white-space: nowrap;
 position: relative;
 box-sizing: border-box;
 cursor: default;
 display: inline-flex;
 align-items: center;
 flex-wrap: nowrap;
 padding: var(--n-padding);
 border-radius: var(--n-border-radius);
 color: var(--n-text-color);
 background-color: var(--n-color);
 transition: 
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 line-height: 1;
 height: var(--n-height);
 font-size: var(--n-font-size);
`,[R("strong",`
 font-weight: var(--n-font-weight-strong);
 `),$("border",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 border: var(--n-border);
 transition: border-color .3s var(--n-bezier);
 `),$("icon",`
 display: flex;
 margin: 0 4px 0 0;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 font-size: var(--n-avatar-size-override);
 `),$("avatar",`
 display: flex;
 margin: 0 6px 0 0;
 `),$("close",`
 margin: var(--n-close-margin);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),R("round",`
 padding: 0 calc(var(--n-height) / 3);
 border-radius: calc(var(--n-height) / 2);
 `,[$("icon",`
 margin: 0 4px 0 calc((var(--n-height) - 8px) / -2);
 `),$("avatar",`
 margin: 0 6px 0 calc((var(--n-height) - 8px) / -2);
 `),R("closable",`
 padding: 0 calc(var(--n-height) / 4) 0 calc(var(--n-height) / 3);
 `)]),R("icon, avatar",[R("round",`
 padding: 0 calc(var(--n-height) / 3) 0 calc(var(--n-height) / 2);
 `)]),R("disabled",`
 cursor: not-allowed !important;
 opacity: var(--n-opacity-disabled);
 `),R("checkable",`
 cursor: pointer;
 box-shadow: none;
 color: var(--n-text-color-checkable);
 background-color: var(--n-color-checkable);
 `,[w("disabled",[M("&:hover","background-color: var(--n-color-hover-checkable);",[w("checked","color: var(--n-text-color-hover-checkable);")]),M("&:active","background-color: var(--n-color-pressed-checkable);",[w("checked","color: var(--n-text-color-pressed-checkable);")])]),R("checked",`
 color: var(--n-text-color-checked);
 background-color: var(--n-color-checked);
 `,[w("disabled",[M("&:hover","background-color: var(--n-color-checked-hover);"),M("&:active","background-color: var(--n-color-checked-pressed);")])])])]),Le=Object.assign(Object.assign(Object.assign({},W.props),je),{bordered:{type:Boolean,default:void 0},checked:Boolean,checkable:Boolean,strong:Boolean,triggerClickOnClose:Boolean,onClose:[Array,Function],onMouseenter:Function,onMouseleave:Function,"onUpdate:checked":Function,onUpdateChecked:Function,internalCloseFocusable:{type:Boolean,default:!0},internalCloseIsButtonTag:{type:Boolean,default:!0},onCheckedChange:Function}),Z=q("n-tag"),Ke=Q({name:"Tag",props:Le,slots:Object,setup(o){const u=T(null),{mergedBorderedRef:l,mergedClsPrefixRef:b,inlineThemeDisabled:t,mergedRtlRef:i,mergedComponentPropsRef:n}=X(o),d=O(()=>{var r,c;return o.size||((c=(r=n?.value)===null||r===void 0?void 0:r.Tag)===null||c===void 0?void 0:c.size)||"medium"}),h=W("Tag","-tag",Fe,_e,o,b);ze(Z,{roundRef:Se(o,"round")});function f(){if(!o.disabled&&o.checkable){const{checked:r,onCheckedChange:c,onUpdateChecked:k,"onUpdate:checked":e}=o;k&&k(!r),e&&e(!r),c&&c(!r)}}function m(r){if(o.triggerClickOnClose||r.stopPropagation(),!o.disabled){const{onClose:c}=o;c&&xe(c,r)}}const g={setTextContent(r){const{value:c}=u;c&&(c.textContent=r)}},P=ke("Tag",i,b),z=O(()=>{const{type:r,color:{color:c,textColor:k}={}}=o,e=d.value,{common:{cubicBezierEaseInOut:a},self:{padding:v,closeMargin:x,borderRadius:C,opacityDisabled:B,textColorCheckable:I,textColorHoverCheckable:H,textColorPressedCheckable:_,textColorChecked:j,colorCheckable:F,colorHoverCheckable:E,colorPressedCheckable:ee,colorChecked:oe,colorCheckedHover:re,colorCheckedPressed:le,closeBorderRadius:ne,fontWeightStrong:ae,[p("colorBordered",r)]:te,[p("closeSize",e)]:se,[p("closeIconSize",e)]:ce,[p("fontSize",e)]:ie,[p("height",e)]:A,[p("color",r)]:de,[p("textColor",r)]:he,[p("border",r)]:ue,[p("closeIconColor",r)]:K,[p("closeIconColorHover",r)]:ge,[p("closeIconColorPressed",r)]:ve,[p("closeColorHover",r)]:be,[p("closeColorPressed",r)]:fe}}=h.value,L=ye(x);return{"--n-font-weight-strong":ae,"--n-avatar-size-override":`calc(${A} - 8px)`,"--n-bezier":a,"--n-border-radius":C,"--n-border":ue,"--n-close-icon-size":ce,"--n-close-color-pressed":fe,"--n-close-color-hover":be,"--n-close-border-radius":ne,"--n-close-icon-color":K,"--n-close-icon-color-hover":ge,"--n-close-icon-color-pressed":ve,"--n-close-icon-color-disabled":K,"--n-close-margin-top":L.top,"--n-close-margin-right":L.right,"--n-close-margin-bottom":L.bottom,"--n-close-margin-left":L.left,"--n-close-size":se,"--n-color":c||(l.value?te:de),"--n-color-checkable":F,"--n-color-checked":oe,"--n-color-checked-hover":re,"--n-color-checked-pressed":le,"--n-color-hover-checkable":E,"--n-color-pressed-checkable":ee,"--n-font-size":ie,"--n-height":A,"--n-opacity-disabled":B,"--n-padding":v,"--n-text-color":k||he,"--n-text-color-checkable":I,"--n-text-color-checked":j,"--n-text-color-hover-checkable":H,"--n-text-color-pressed-checkable":_}}),y=t?Y("tag",O(()=>{let r="";const{type:c,color:{color:k,textColor:e}={}}=o;return r+=c[0],r+=d.value[0],k&&(r+=`a${U(k)}`),e&&(r+=`b${U(e)}`),l.value&&(r+="c"),r}),z,o):void 0;return Object.assign(Object.assign({},g),{rtlEnabled:P,mergedClsPrefix:b,contentRef:u,mergedBordered:l,handleClick:f,handleCloseClick:m,cssVars:t?void 0:z,themeClass:y?.themeClass,onRender:y?.onRender})},render(){var o,u;const{mergedClsPrefix:l,rtlEnabled:b,closable:t,color:{borderColor:i}={},round:n,onRender:d,$slots:h}=this;d?.();const f=D(h.avatar,g=>g&&S("div",{class:`${l}-tag__avatar`},g)),m=D(h.icon,g=>g&&S("div",{class:`${l}-tag__icon`},g));return S("div",{class:[`${l}-tag`,this.themeClass,{[`${l}-tag--rtl`]:b,[`${l}-tag--strong`]:this.strong,[`${l}-tag--disabled`]:this.disabled,[`${l}-tag--checkable`]:this.checkable,[`${l}-tag--checked`]:this.checkable&&this.checked,[`${l}-tag--round`]:n,[`${l}-tag--avatar`]:f,[`${l}-tag--icon`]:m,[`${l}-tag--closable`]:t}],style:this.cssVars,onClick:this.handleClick,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},m||f,S("span",{class:`${l}-tag__content`,ref:"contentRef"},(u=(o=this.$slots).default)===null||u===void 0?void 0:u.call(o)),!this.checkable&&t?S(pe,{clsPrefix:l,class:`${l}-tag__close`,disabled:this.disabled,onClick:this.handleCloseClick,focusable:this.internalCloseFocusable,round:n,isButtonTag:this.internalCloseIsButtonTag,absolute:!0}):null,!this.checkable&&this.mergedBordered?S("div",{class:`${l}-tag__border`,style:{borderColor:i}}):null)}});function we(o){const{borderRadius:u,avatarColor:l,cardColor:b,fontSize:t,heightTiny:i,heightSmall:n,heightMedium:d,heightLarge:h,heightHuge:f,modalColor:m,popoverColor:g}=o;return{borderRadius:u,fontSize:t,border:`2px solid ${b}`,heightTiny:i,heightSmall:n,heightMedium:d,heightLarge:h,heightHuge:f,color:V(b,l),colorModal:V(m,l),colorPopover:V(g,l)}}const We={common:J,self:we},Ve=q("n-avatar-group"),Ne=N("avatar",`
 width: var(--n-merged-size);
 height: var(--n-merged-size);
 color: #FFF;
 font-size: var(--n-font-size);
 display: inline-flex;
 position: relative;
 overflow: hidden;
 text-align: center;
 border: var(--n-border);
 border-radius: var(--n-border-radius);
 --n-merged-color: var(--n-color);
 background-color: var(--n-merged-color);
 transition:
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[Pe(M("&","--n-merged-color: var(--n-color-modal);")),Ie(M("&","--n-merged-color: var(--n-color-popover);")),M("img",`
 width: 100%;
 height: 100%;
 `),$("text",`
 white-space: nowrap;
 display: inline-block;
 position: absolute;
 left: 50%;
 top: 50%;
 `),N("icon",`
 vertical-align: bottom;
 font-size: calc(var(--n-merged-size) - 6px);
 `),$("text","line-height: 1.25")]),De=Object.assign(Object.assign({},W.props),{size:[String,Number],src:String,circle:{type:Boolean,default:void 0},objectFit:String,round:{type:Boolean,default:void 0},bordered:{type:Boolean,default:void 0},onError:Function,fallbackSrc:String,intersectionObserverOptions:Object,lazy:Boolean,onLoad:Function,renderPlaceholder:Function,renderFallback:Function,imgProps:Object,color:String}),Ge=Q({name:"Avatar",props:De,slots:Object,setup(o){const{mergedClsPrefixRef:u,inlineThemeDisabled:l}=X(o),b=T(!1);let t=null;const i=T(null),n=T(null),d=()=>{const{value:e}=i;if(e&&(t===null||t!==e.innerHTML)){t=e.innerHTML;const{value:a}=n;if(a){const{offsetWidth:v,offsetHeight:x}=a,{offsetWidth:C,offsetHeight:B}=e,I=.9,H=Math.min(v/C*I,x/B*I,1);e.style.transform=`translateX(-50%) translateY(-50%) scale(${H})`}}},h=G(Ve,null),f=O(()=>{const{size:e}=o;if(e)return e;const{size:a}=h||{};return a||"medium"}),m=W("Avatar","-avatar",Ne,We,o,u),g=G(Z,null),P=O(()=>{if(h)return!0;const{round:e,circle:a}=o;return e!==void 0||a!==void 0?e||a:g?g.roundRef.value:!1}),z=O(()=>h?!0:o.bordered||!1),y=O(()=>{const e=f.value,a=P.value,v=z.value,{color:x}=o,{self:{borderRadius:C,fontSize:B,color:I,border:H,colorModal:_,colorPopover:j},common:{cubicBezierEaseInOut:F}}=m.value;let E;return typeof e=="number"?E=`${e}px`:E=m.value.self[p("height",e)],{"--n-font-size":B,"--n-border":v?H:"none","--n-border-radius":a?"50%":C,"--n-color":x||I,"--n-color-modal":x||_,"--n-color-popover":x||j,"--n-bezier":F,"--n-merged-size":`var(--n-avatar-size-override, ${E})`}}),r=l?Y("avatar",O(()=>{const e=f.value,a=P.value,v=z.value,{color:x}=o;let C="";return e&&(typeof e=="number"?C+=`a${e}`:C+=e[0]),a&&(C+="b"),v&&(C+="c"),x&&(C+=U(x)),C}),y,o):void 0,c=T(!o.lazy);$e(()=>{if(o.lazy&&o.intersectionObserverOptions){let e;const a=Oe(()=>{e?.(),e=void 0,o.lazy&&(e=Ce(n.value,o.intersectionObserverOptions,c))});Be(()=>{a(),e?.()})}}),He(()=>{var e;return o.src||((e=o.imgProps)===null||e===void 0?void 0:e.src)},()=>{b.value=!1});const k=T(!o.lazy);return{textRef:i,selfRef:n,mergedRoundRef:P,mergedClsPrefix:u,fitTextTransform:d,cssVars:l?void 0:y,themeClass:r?.themeClass,onRender:r?.onRender,hasLoadError:b,shouldStartLoading:c,loaded:k,mergedOnError:e=>{if(!c.value)return;b.value=!0;const{onError:a,imgProps:{onError:v}={}}=o;a?.(e),v?.(e)},mergedOnLoad:e=>{const{onLoad:a,imgProps:{onLoad:v}={}}=o;a?.(e),v?.(e),k.value=!0}}},render(){var o,u;const{$slots:l,src:b,mergedClsPrefix:t,lazy:i,onRender:n,loaded:d,hasLoadError:h,imgProps:f={}}=this;n?.();let m;const g=!d&&!h&&(this.renderPlaceholder?this.renderPlaceholder():(u=(o=this.$slots).placeholder)===null||u===void 0?void 0:u.call(o));return this.hasLoadError?m=this.renderFallback?this.renderFallback():Re(l.fallback,()=>[S("img",{src:this.fallbackSrc,style:{objectFit:this.objectFit}})]):m=D(l.default,P=>{if(P)return S(Ee,{onResize:this.fitTextTransform},{default:()=>S("span",{ref:"textRef",class:`${t}-avatar__text`},P)});if(b||f.src){const z=this.src||f.src;return S("img",Object.assign(Object.assign({},f),{loading:me&&!this.intersectionObserverOptions&&i?"lazy":"eager",src:i&&this.intersectionObserverOptions?this.shouldStartLoading?z:void 0:z,"data-image-src":z,onLoad:this.mergedOnLoad,onError:this.mergedOnError,style:[f.style||"",{objectFit:this.objectFit},g?{height:"0",width:"0",visibility:"hidden",position:"absolute"}:""]}))}}),S("span",{ref:"selfRef",class:[`${t}-avatar`,this.themeClass],style:this.cssVars},m,i&&g)}});export{Ge as _,Ke as a};
