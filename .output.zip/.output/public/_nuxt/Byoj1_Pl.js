import{g as ue}from"./Dcn1kh8z.js";import{br as It,bp as Dt,a0 as Nt,an as Vt,bk as Tt,b2 as $t,P as Et,$ as he,ah as y,bs as pe,am as jt,aU as Mt,b5 as D,aV as nt,aT as ot,E as x,p as At,r as c,o as T,s as f,y as at,a8 as Bt,V as Ke,be as We,bN as Ot,bH as Lt,h as Ut,bm as Xt,bK as Ft,aY as Kt,bJ as ce,aM as Ye,bE as st,bF as Wt,aQ as ee,aH as Ze,aO as Yt,af as Zt,aR as te,aZ as j,K as L,H as g,bl as $,bq as de,W as Ie,a as De,b7 as Ne,I as He,bM as qe,J as Ht,Z as qt}from"./O-zoPhqF.js";import{c as Jt,_ as Qt}from"./BDrcshJJ.js";import{u as Gt}from"./bM5Y2li9.js";function en(e){return It(Dt(e).toLowerCase())}var Je=Jt(function(e,o,a){return o=o.toLowerCase(),e+(a?en(o):o)});function tn(){return{dotSize:"8px",dotColor:"rgba(255, 255, 255, .3)",dotColorActive:"rgba(255, 255, 255, 1)",dotColorFocus:"rgba(255, 255, 255, .5)",dotLineWidth:"16px",dotLineWidthActive:"24px",arrowColor:"#eee"}}const nn={common:Nt,self:tn},lt=Et("n-carousel-methods");function on(e){$t(lt,e)}function $e(e="unknown",o="component"){const a=Vt(lt);return a||Tt(e,`\`${o}\` must be placed inside \`n-carousel\`.`),a}function an(){return y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"})))}function sn(){return y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"})))}const ln=he({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:o}=pe(e),{isVertical:a,isPrevDisabled:i,isNextDisabled:v,prev:h,next:P}=$e();return{mergedClsPrefix:o,isVertical:a,isPrevDisabled:i,isNextDisabled:v,prev:h,next:P}},render(){const{mergedClsPrefix:e}=this;return y("div",{class:`${e}-carousel__arrow-group`},y("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},an()),y("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},sn()))}}),rn={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},un=he({name:"CarouselDots",props:rn,setup(e){const{mergedClsPrefixRef:o}=pe(e),a=D([]),i=$e();function v(p,d){switch(p.key){case"Enter":case" ":p.preventDefault(),i.to(d);return}e.keyboard&&S(p)}function h(p){e.trigger==="hover"&&i.to(p)}function P(p){e.trigger==="click"&&i.to(p)}function S(p){var d;if(p.shiftKey||p.altKey||p.ctrlKey||p.metaKey)return;const m=(d=document.activeElement)===null||d===void 0?void 0:d.nodeName.toLowerCase();if(m==="input"||m==="textarea")return;const{code:_}=p,M=_==="PageUp"||_==="ArrowUp",U=_==="PageDown"||_==="ArrowDown",k=_==="PageUp"||_==="ArrowRight",R=_==="PageDown"||_==="ArrowLeft",A=i.isVertical(),X=A?M:k,B=A?U:R;!X&&!B||(p.preventDefault(),X&&!i.isNextDisabled()?(i.next(),C(i.currentIndexRef.value)):B&&!i.isPrevDisabled()&&(i.prev(),C(i.currentIndexRef.value)))}function C(p){var d;(d=a.value[p])===null||d===void 0||d.focus()}return Mt(()=>a.value.length=0),{mergedClsPrefix:o,dotEls:a,handleKeydown:v,handleMouseenter:h,handleClick:P}},render(){const{mergedClsPrefix:e,dotEls:o}=this;return y("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},jt(this.total,a=>{const i=a===this.currentIndex;return y("div",{"aria-selected":i,ref:v=>o.push(v),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,i&&`${e}-carousel__dot--active`],key:a,onClick:()=>{this.handleClick(a)},onMouseenter:()=>{this.handleMouseenter(a)},onKeydown:v=>{this.handleKeydown(v,a)}})}))}}),ve="CarouselItem";function cn(e){var o;return((o=e.type)===null||o===void 0?void 0:o.name)===ve}const rt=he({name:ve,setup(e){const{mergedClsPrefixRef:o}=pe(e),a=$e(Je(ve),`n-${Je(ve)}`),i=D(),v=x(()=>{const{value:d}=i;return d?a.getSlideIndex(d):-1}),h=x(()=>a.isPrev(v.value)),P=x(()=>a.isNext(v.value)),S=x(()=>a.isActive(v.value)),C=x(()=>a.getSlideStyle(v.value));nt(()=>{a.addSlide(i.value)}),ot(()=>{a.removeSlide(i.value)});function p(d){const{value:m}=v;m!==void 0&&a?.onCarouselItemClick(m,d)}return{mergedClsPrefix:o,selfElRef:i,isPrev:h,isNext:P,isActive:S,index:v,style:C,handleClick:p}},render(){var e;const{$slots:o,mergedClsPrefix:a,isPrev:i,isNext:v,isActive:h,index:P,style:S}=this,C=[`${a}-carousel__slide`,{[`${a}-carousel__slide--current`]:h,[`${a}-carousel__slide--prev`]:i,[`${a}-carousel__slide--next`]:v}];return y("div",{ref:"selfElRef",class:C,role:"option",tabindex:"-1","data-index":P,"aria-hidden":!h,style:S,onClickCapture:this.handleClick},(e=o.default)===null||e===void 0?void 0:e.call(o,{isPrev:i,isNext:v,isActive:h,index:P}))}}),dn=At("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[c("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[c("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[T("> img",`
 display: block;
 `)])]),c("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[f("dot",[c("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[T("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),f("active",`
 background-color: var(--n-dot-color-active);
 `)])]),f("line",[c("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[T("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),f("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),c("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[T("svg",`
 height: 1em;
 width: 1em;
 `),T("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),f("vertical",`
 touch-action: pan-x;
 `,[c("slides",`
 flex-direction: column;
 `),f("fade",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),f("card",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[f("current",`
 transform: translateY(-50%) translateZ(0);
 `),f("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),f("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),f("usercontrol",[c("slides",[T(">",[T("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),f("left",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[f("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[f("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `)]),c("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),f("vertical",[c("arrow",`
 transform: rotate(90deg);
 `)]),f("show-arrow",[f("bottom",[c("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),f("top",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),f("left",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),f("right",[c("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),f("left",[c("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[T("> *:first-child",`
 margin-bottom: 12px;
 `)])]),f("right",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[f("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[f("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[T("> *:first-child",`
 margin-bottom: 12px;
 `)])]),f("top",[c("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[f("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 top: 12px;
 right: 12px;
 `,[T("> *:first-child",`
 margin-right: 12px;
 `)])]),f("bottom",[c("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[f("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[T("> *:first-child",`
 margin-right: 12px;
 `)])]),f("fade",[c("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[f("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),f("card",[c("slides",`
 perspective: 1000px;
 `),c("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[f("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),f("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),f("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]);function fn(e){const{length:o}=e;return o>1&&(e.push(Qe(e[0],0,"append")),e.unshift(Qe(e[o-1],o-1,"prepend"))),e}function Qe(e,o,a){return at(e,{key:`carousel-item-duplicate-${o}-${a}`})}function Ge(e,o,a){return o===1?0:a?e===0?o-3:e===o-1?0:e-1:e}function Ve(e,o){return o?e+1:e}function vn(e,o,a){return e<0?null:e===0?a?o-1:null:e-1}function hn(e,o,a){return e>o-1?null:e===o-1?a?0:null:e+1}function pn(e,o){return o&&e>3?e-2:e}function et(e){return window.TouchEvent&&e instanceof window.TouchEvent}function tt(e,o){let{offsetWidth:a,offsetHeight:i}=e;if(o){const v=getComputedStyle(e);a=a-Number.parseFloat(v.getPropertyValue("padding-left"))-Number.parseFloat(v.getPropertyValue("padding-right")),i=i-Number.parseFloat(v.getPropertyValue("padding-top"))-Number.parseFloat(v.getPropertyValue("padding-bottom"))}return{width:a,height:i}}function fe(e,o,a){return e<o?o:e>a?a:e}function gn(e){if(e===void 0)return 0;if(typeof e=="number")return e;const o=/^((\d+)?\.?\d+?)(ms|s)?$/,a=e.match(o);if(a){const[,i,,v="ms"]=a;return Number(i)*(v==="ms"?1:1e3)}return 0}const mn=["transitionDuration","transitionTimingFunction"],xn=Object.assign(Object.assign({},st.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Te=!1;const bn=he({name:"Carousel",props:xn,slots:Object,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:a}=pe(e),i=D(null),v=D(null),h=D([]),P={value:[]},S=x(()=>e.direction==="vertical"),C=x(()=>S.value?"height":"width"),p=x(()=>S.value?"bottom":"right"),d=x(()=>e.effect==="slide"),m=x(()=>e.loop&&e.slidesPerView===1&&d.value),_=x(()=>e.effect==="custom"),M=x(()=>!d.value||e.centeredSlides?1:e.slidesPerView),U=x(()=>_.value?1:e.slidesPerView),k=x(()=>M.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),R=D({width:0,height:0}),A=D(0),X=x(()=>{const{value:t}=h;if(!t.length)return[];A.value;const{value:n}=k;if(n)return t.map(w=>tt(w));const{value:s}=U,{value:r}=R,{value:u}=C;let l=r[u];if(s!=="auto"){const{spaceBetween:w}=e,I=l-(s-1)*w,ie=1/Math.max(1,s);l=I*ie}const b=Object.assign(Object.assign({},r),{[u]:l});return t.map(()=>b)}),B=x(()=>{const{value:t}=X;if(!t.length)return[];const{centeredSlides:n,spaceBetween:s}=e,{value:r}=C,{[r]:u}=R.value;let l=0;return t.map(({[r]:b})=>{let w=l;return n&&(w+=(b-u)/2),l+=b+s,w})}),Ee=D(!1),ge=x(()=>{const{transitionStyle:t}=e;return t?Ze(t,mn):{}}),me=x(()=>_.value?0:gn(ge.value.transitionDuration)),je=x(()=>{const{value:t}=h;if(!t.length)return[];const n=!(k.value||U.value===1),s=b=>{if(n){const{value:w}=C;return{[w]:`${X.value[b][w]}px`}}};if(_.value)return t.map((b,w)=>s(w));const{effect:r,spaceBetween:u}=e,{value:l}=p;return t.reduce((b,w,I)=>{const ie=Object.assign(Object.assign({},s(I)),{[`margin-${l}`]:`${u}px`});return b.push(ie),Ee.value&&(r==="fade"||r==="card")&&Object.assign(ie,ge.value),b},[])}),z=x(()=>{const{value:t}=M,{length:n}=h.value;if(t!=="auto")return Math.max(n-t,0)+1;{const{value:s}=X,{length:r}=s;if(!r)return n;const{value:u}=B,{value:l}=C,b=R.value[l];let w=s[s.length-1][l],I=r;for(;I>1&&w<b;)I--,w+=u[I]-u[I-1];return fe(I+1,1,r)}}),xe=x(()=>pn(z.value,m.value)),it=Ve(e.defaultIndex,m.value),be=D(Ge(it,z.value,m.value)),E=Gt(Xt(e,"currentIndex"),be),N=x(()=>Ve(E.value,m.value));function q(t){var n,s;t=fe(t,0,z.value-1);const r=Ge(t,z.value,m.value),{value:u}=E;r!==E.value&&(be.value=r,(n=e["onUpdate:currentIndex"])===null||n===void 0||n.call(e,r,u),(s=e.onUpdateCurrentIndex)===null||s===void 0||s.call(e,r,u))}function we(t=N.value){return vn(t,z.value,e.loop)}function ye(t=N.value){return hn(t,z.value,e.loop)}function ut(t){const n=W(t);return n!==null&&we()===n&&z.value>1}function ct(t){const n=W(t);return n!==null&&ye()===n&&z.value>1}function Me(t){return N.value===W(t)}function dt(t){return E.value===t}function Ae(){return we()===null}function Be(){return ye()===null}let K=0;function Se(t){const n=fe(Ve(t,m.value),0,z.value);(t!==E.value||n!==N.value)&&q(n)}function ne(){const t=we();t!==null&&(K=-1,q(t))}function J(){const t=ye();t!==null&&(K=1,q(t))}let V=!1;function ft(){(!V||!m.value)&&ne()}function vt(){(!V||!m.value)&&J()}let F=0;const Ce=D({});function oe(t,n=0){Ce.value=Object.assign({},ge.value,{transform:S.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${n}ms`})}function Q(t=0){d.value?_e(N.value,t):F!==0&&(!V&&t>0&&(V=!0),oe(F=0,t))}function _e(t,n){const s=Oe(t);s!==F&&n>0&&(V=!0),F=Oe(N.value),oe(s,n)}function Oe(t){let n;return t>=z.value-1?n=Le():n=B.value[t]||0,n}function Le(){if(M.value==="auto"){const{value:t}=C,{[t]:n}=R.value,{value:s}=B,r=s[s.length-1];let u;if(r===void 0)u=n;else{const{value:l}=X;u=r+l[l.length-1][t]}return u-n}else{const{value:t}=B;return t[z.value-1]||0}}const G={currentIndexRef:E,to:Se,prev:ft,next:vt,isVertical:()=>S.value,isHorizontal:()=>!S.value,isPrev:ut,isNext:ct,isActive:Me,isPrevDisabled:Ae,isNextDisabled:Be,getSlideIndex:W,getSlideStyle:gt,addSlide:ht,removeSlide:pt,onCarouselItemClick:mt};on(G);function ht(t){t&&h.value.push(t)}function pt(t){if(!t)return;const n=W(t);n!==-1&&h.value.splice(n,1)}function W(t){return typeof t=="number"?t:t?h.value.indexOf(t):-1}function gt(t){const n=W(t);if(n!==-1){const s=[je.value[n]],r=G.isPrev(n),u=G.isNext(n);return r&&s.push(e.prevSlideStyle||""),u&&s.push(e.nextSlideStyle||""),Yt(s)}}let Pe=0,ke=0,O=0,Re=0,ae=!1,ze=!1;function mt(t,n){let s=!V&&!ae&&!ze;e.effect==="card"&&s&&!Me(t)&&(Se(t),s=!1),s||(n.preventDefault(),n.stopPropagation())}let se=null;function le(){se&&(clearInterval(se),se=null)}function Y(){le(),!e.autoplay||xe.value<2||(se=window.setInterval(J,e.interval))}function Ue(t){var n;if(Te||!(!((n=v.value)===null||n===void 0)&&n.contains(Zt(t))))return;Te=!0,ae=!0,ze=!1,Re=Date.now(),le(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const s=et(t)?t.touches[0]:t;S.value?ke=s.clientY:Pe=s.clientX,e.touchable&&(te("touchmove",document,re),te("touchend",document,Z),te("touchcancel",document,Z)),e.draggable&&(te("mousemove",document,re),te("mouseup",document,Z))}function re(t){const{value:n}=S,{value:s}=C,r=et(t)?t.touches[0]:t,u=n?r.clientY-ke:r.clientX-Pe,l=R.value[s];O=fe(u,-l,l),t.cancelable&&t.preventDefault(),d.value&&oe(F-O,0)}function Z(){const{value:t}=N;let n=t;if(!V&&O!==0&&d.value){const s=F-O,r=[...B.value.slice(0,z.value-1),Le()];let u=null;for(let l=0;l<r.length;l++){const b=Math.abs(r[l]-s);if(u!==null&&u<b)break;u=b,n=l}}if(n===t){const s=Date.now()-Re,{value:r}=C,u=R.value[r];O>u/2||O/s>.4?ne():(O<-u/2||O/s<-.4)&&J()}n!==null&&n!==t?(ze=!0,q(n),Ye(()=>{(!m.value||be.value!==E.value)&&Q(me.value)})):Q(me.value),Xe(),Y()}function Xe(){ae&&(Te=!1),ae=!1,Pe=0,ke=0,O=0,Re=0,ee("touchmove",document,re),ee("touchend",document,Z),ee("touchcancel",document,Z),ee("mousemove",document,re),ee("mouseup",document,Z)}function xt(){if(d.value&&V){const{value:t}=N;_e(t,0)}else Y();d.value&&(Ce.value.transitionDuration="0ms"),V=!1}function bt(t){if(t.preventDefault(),V)return;let{deltaX:n,deltaY:s}=t;t.shiftKey&&!n&&(n=s);const r=-1,u=1,l=(n||s)>0?u:r;let b=0,w=0;S.value?w=l:b=l;const I=10;(w*s>=I||b*n>=I)&&(l===u&&!Be()?J():l===r&&!Ae()&&ne())}function wt(){R.value=tt(i.value,!0),Y()}function yt(){k.value&&A.value++}function St(){e.autoplay&&le()}function Ct(){e.autoplay&&Y()}nt(()=>{Ft(Y),requestAnimationFrame(()=>Ee.value=!0)}),ot(()=>{Xe(),le()}),Kt(()=>{const{value:t}=h,{value:n}=P,s=new Map,r=l=>s.has(l)?s.get(l):-1;let u=!1;for(let l=0;l<t.length;l++){const b=n.findIndex(w=>w.el===t[l]);b!==l&&(u=!0),s.set(t[l],b)}u&&t.sort((l,b)=>r(l)-r(b))}),ce(N,(t,n)=>{if(t===n){K=0;return}if(Y(),d.value){if(m.value){const{value:s}=z;K===-1&&n===1&&t===s-2?t=0:K===1&&n===s-2&&t===1&&(t=s-1)}_e(t,me.value)}else Q();K=0},{immediate:!0}),ce([m,M],()=>{Ye(()=>{q(N.value)})}),ce(B,()=>{d.value&&Q()},{deep:!0}),ce(d,t=>{t?Q():(V=!1,oe(F=0))});const _t=x(()=>({onTouchstartPassive:e.touchable?Ue:void 0,onMousedown:e.draggable?Ue:void 0,onWheel:e.mousewheel?bt:void 0})),Pt=x(()=>Object.assign(Object.assign({},Ze(G,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:xe.value,currentIndex:E.value})),kt=x(()=>({total:xe.value,currentIndex:E.value,to:G.to})),Rt={getCurrentIndex:()=>E.value,to:Se,prev:ne,next:J},zt=st("Carousel","-carousel",dn,nn,e,o),Fe=x(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:n,dotColor:s,dotColorActive:r,dotColorFocus:u,dotLineWidth:l,dotLineWidthActive:b,arrowColor:w}}=zt.value;return{"--n-bezier":t,"--n-dot-color":s,"--n-dot-color-focus":u,"--n-dot-color-active":r,"--n-dot-size":n,"--n-dot-line-width":l,"--n-dot-line-width-active":b,"--n-arrow-color":w}}),H=a?Wt("carousel",void 0,Fe,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:o,selfElRef:i,slidesElRef:v,slideVNodes:P,duplicatedable:m,userWantsControl:_,autoSlideSize:k,realIndex:N,slideStyles:je,translateStyle:Ce,slidesControlListeners:_t,handleTransitionEnd:xt,handleResize:wt,handleSlideResize:yt,handleMouseenter:St,handleMouseleave:Ct,isActive:dt,arrowSlotProps:Pt,dotSlotProps:kt},Rt),{cssVars:a?void 0:Fe,themeClass:H?.themeClass,onRender:H?.onRender})},render(){var e;const{mergedClsPrefix:o,showArrow:a,userWantsControl:i,slideStyles:v,dotType:h,dotPlacement:P,slidesControlListeners:S,transitionProps:C={},arrowSlotProps:p,dotSlotProps:d,$slots:{default:m,dots:_,arrow:M}}=this,U=m&&Bt(m())||[];let k=wn(U);return k.length||(k=U.map(R=>y(rt,null,{default:()=>at(R)}))),this.duplicatedable&&(k=fn(k)),this.slideVNodes.value=k,this.autoSlideSize&&(k=k.map(R=>y(Ke,{onResize:this.handleSlideResize},{default:()=>R}))),(e=this.onRender)===null||e===void 0||e.call(this),y("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${o}-carousel`,this.direction==="vertical"&&`${o}-carousel--vertical`,this.showArrow&&`${o}-carousel--show-arrow`,`${o}-carousel--${P}`,`${o}-carousel--${this.direction}`,`${o}-carousel--${this.effect}`,i&&`${o}-carousel--usercontrol`],style:this.cssVars},S,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),y(Ke,{onResize:this.handleResize},{default:()=>y("div",{ref:"slidesElRef",class:`${o}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},i?k.map((R,A)=>y("div",{style:v[A],key:A},Ot(y(Ut,Object.assign({},C),{default:()=>R}),[[Lt,this.isActive(A)]]))):k)}),this.showDots&&d.total>1&&We(_,d,()=>[y(un,{key:h+P,total:d.total,currentIndex:d.currentIndex,dotType:h,trigger:this.trigger,keyboard:this.keyboard})]),a&&We(M,p,()=>[y(ln,null)]))}});function wn(e){return e.reduce((o,a)=>(cn(a)&&o.push(a),o),[])}const yn={class:"min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50"},Sn={class:"w-full bg-gradient-to-r from-purple-400 text-white py-14 px-6"},Cn={class:"max-w-5xl mx-auto text-center"},_n={class:"text-[clamp(2rem,5vw,3.5rem)] font-bold mb-3 tracking-wide animate-[fadeIn_1.5s_ease-in-out]"},Pn={class:"max-w-5xl mx-auto px-4 sm:px-6 py-10"},kn={class:"bg-white/95 backdrop-blur-lg rounded-3xl shadow-2xl p-6 sm:p-10 hover:shadow-indigo-200/30 transition-all duration-500"},Rn={class:"flex flex-col md:flex-row gap-8 items-center"},zn={class:"w-36 h-36 md:w-44 md:h-44 rounded-full overflow-hidden border-4 border-white shadow-xl hover:rotate-6 hover:scale-105 transition-all duration-500"},In=["src","alt"],Dn={class:"flex-1 text-center md:text-left"},Nn={class:"text-3xl md:text-4xl font-bold text-gray-800 mb-2"},Vn={class:"text-lg text-gray-400 ml-2"},Tn={class:"flex flex-wrap gap-3 justify-center md:justify-start my-4"},$n={class:"px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"},En={class:"px-3 py-1 bg-green-100 text-green-600 rounded-full text-sm"},jn={class:"px-3 py-1 bg-purple-100 text-purple-600 rounded-full text-sm"},Mn={class:"text-gray-600 mb-2"},An={class:"text-gray-600 mb-4"},Bn={class:"flex flex-wrap gap-2 mt-2"},On={class:"mt-14"},Ln={class:"grid grid-cols-1 md:grid-cols-2 gap-6"},Un=["src"],Xn=["src","alt","onClick"],Fn={class:"text-gray-700 font-medium text-lg"},Kn={class:"text-gray-400 text-sm mt-1"},qn={__name:"PersonCard",props:{person:{type:Object,required:!0}},setup(e){const o=D(!1),a=D(""),i=v=>{a.value=v,console.log("url===========",v),o.value=!0};return(v,h)=>{const P=rt,S=bn,C=Qt;return j(),L("div",yn,[g("div",Sn,[g("div",Cn,[g("h1",_n," 🌟 欢迎来到 "+$(e.person.name)+" 的个人主页 ",1),h[1]||(h[1]=g("p",{class:"text-[clamp(1rem,2vw,1.25rem)] opacity-90 animate-[fadeIn_1.8s_ease-in-out]"}," 记录生活 · 记录友情 · 记录搞笑瞬间 ",-1))])]),g("div",Pn,[g("div",kn,[g("div",Rn,[g("div",zn,[g("img",{src:de(ue)(e.person.avatar,e.person.ImageUrl),alt:e.person.name,class:"w-full h-full object-cover"},null,8,In)]),g("div",Dn,[g("h2",Nn,[Ie($(e.person.name)+" ",1),g("span",Vn,$(e.person.nameEn),1)]),g("div",Tn,[g("span",$n,"身高 "+$(e.person.height)+"cm",1),g("span",En,"体重 "+$(e.person.weight)+"kg",1),g("span",jn,$(e.person.age===0?"年龄保密":e.person.age+"岁"),1)]),g("p",Mn,[h[2]||(h[2]=g("b",null,"性格：",-1)),Ie($(e.person.character),1)]),g("p",An,[h[3]||(h[3]=g("b",null,"简介：",-1)),Ie($(e.person.describe),1)]),g("div",null,[h[4]||(h[4]=g("b",{class:"text-gray-700"},"爱好：",-1)),g("div",Bn,[(j(!0),L(De,null,Ne(e.person.hobby,(p,d)=>(j(),L("span",{key:d,class:"px-2 py-1 bg-orange-100 text-orange-600 rounded-md text-sm"},$(p),1))),128))])])])])]),g("div",On,[h[5]||(h[5]=g("h2",{class:"text-2xl font-bold text-center text-gray-800 mb-8"}," 📸 生活瞬间 & 搞笑经历 ",-1)),g("div",Ln,[(j(!0),L(De,null,Ne(e.person.guoWang,(p,d)=>(j(),L("div",{key:d,class:"bg-white rounded-2xl shadow-lg p-5 hover:shadow-xl transition-all"},[p.imageName.length?(j(),He(S,{key:0,touchable:p.imageName.length>=2,class:"w-full h-52 md:h-64 rounded-xl overflow-hidden mb-4",autoplay:!1,loop:"","show-arrows":"hover"},{default:qe(()=>[(j(!0),L(De,null,Ne(p.imageName,(m,_)=>(j(),He(P,{key:_},{default:qe(()=>[m.endsWith(".mp4")?(j(),L("video",{key:0,src:de(ue)(m,e.person.ImageUrl),controls:"",controlslist:"nodownload nofullscreen noremoteplayback",disablepictureinpicture:"",class:"w-full h-full object-contain bg-black"},null,8,Un)):(j(),L("img",{key:1,src:de(ue)(m,e.person.ImageUrl),alt:m,class:"w-full h-full object-cover cursor-pointer",onClick:M=>i(de(ue)(m,e.person.ImageUrl))},null,8,Xn))]),_:2},1024))),128))]),_:2},1032,["touchable"])):Ht("",!0),g("p",Fn,$(p.des),1),g("p",Kn,$(p.date),1)]))),128))])])]),qt(C,{visible:o.value,"onUpdate:visible":h[0]||(h[0]=p=>o.value=p),src:a.value},null,8,["visible","src"])])}}};export{qn as _};
