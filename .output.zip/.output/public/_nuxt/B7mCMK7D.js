import{an as Re,aa as $r,bJ as qe,aT as Zt,$ as se,ah as p,b9 as Xt,p as _,o as V,r as S,ak as Jt,e as Qt,bd as Oe,c as Ne,bD as Pr,bm as me,d as en,Y as rn,bi as tn,a0 as zr,w as Xe,P as lr,s as B,t as ze,b5 as I,be as nn,E as O,bf as Ae,S as an,a as on,V as ln,bs as Ue,bE as _e,aC as sn,bt as dn,bw as fr,aV as Ar,bK as hr,bA as un,bF as Er,aM as gr,aR as vr,u as U,aQ as pr,b2 as Ke,Q as ne,ad as cn,aI as Je,A as fn,h as hn,O as mr,a9 as gn,bI as br}from"./O-zoPhqF.js";import{u as vn}from"./Bsz9TjBg.js";import{u as pn,g as Or,f as Qe}from"./bM5Y2li9.js";function mn(r,e,t){var n;const a=Re(r,null);if(a===null)return;const l=(n=$r())===null||n===void 0?void 0:n.proxy;qe(t,s),s(t.value),Zt(()=>{s(void 0,t.value)});function s(m,c){if(!a)return;const g=a[e];c!==void 0&&o(g,c),m!==void 0&&u(g,m)}function o(m,c){m[c]||(m[c]=[]),m[c].splice(m[c].findIndex(g=>g===l),1)}function u(m,c){m[c]||(m[c]=[]),~m[c].findIndex(g=>g===l)||m[c].push(l)}}const bn=se({name:"ChevronDown",render(){return p("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},p("path",{d:"M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",fill:"currentColor"}))}}),yn=Xt("clear",()=>p("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},p("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},p("g",{fill:"currentColor","fill-rule":"nonzero"},p("path",{d:"M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"}))))),xn=se({name:"Eye",render(){return p("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},p("path",{d:"M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"32"}),p("circle",{cx:"256",cy:"256",r:"80",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"}))}}),wn=se({name:"EyeOff",render(){return p("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},p("path",{d:"M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",fill:"currentColor"}),p("path",{d:"M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",fill:"currentColor"}),p("path",{d:"M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",fill:"currentColor"}),p("path",{d:"M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",fill:"currentColor"}),p("path",{d:"M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",fill:"currentColor"}))}}),Cn=_("base-clear",`
 flex-shrink: 0;
 height: 1em;
 width: 1em;
 position: relative;
`,[V(">",[S("clear",`
 font-size: var(--n-clear-size);
 height: 1em;
 width: 1em;
 cursor: pointer;
 color: var(--n-clear-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 `,[V("&:hover",`
 color: var(--n-clear-color-hover)!important;
 `),V("&:active",`
 color: var(--n-clear-color-pressed)!important;
 `)]),S("placeholder",`
 display: flex;
 `),S("clear, placeholder",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[Jt({originalTransform:"translateX(-50%) translateY(-50%)",left:"50%",top:"50%"})])])]),rr=se({name:"BaseClear",props:{clsPrefix:{type:String,required:!0},show:Boolean,onClear:Function},setup(r){return Pr("-base-clear",Cn,me(r,"clsPrefix")),{handleMouseDown(e){e.preventDefault()}}},render(){const{clsPrefix:r}=this;return p("div",{class:`${r}-base-clear`},p(Qt,null,{default:()=>{var e,t;return this.show?p("div",{key:"dismiss",class:`${r}-base-clear__clear`,onClick:this.onClear,onMousedown:this.handleMouseDown,"data-clear":!0},Oe(this.$slots.icon,()=>[p(Ne,{clsPrefix:r},{default:()=>p(yn,null)})])):p("div",{key:"icon",class:`${r}-base-clear__placeholder`},(t=(e=this.$slots).placeholder)===null||t===void 0?void 0:t.call(e))}}))}}),Sn=se({name:"InternalSelectionSuffix",props:{clsPrefix:{type:String,required:!0},showArrow:{type:Boolean,default:void 0},showClear:{type:Boolean,default:void 0},loading:{type:Boolean,default:!1},onClear:Function},setup(r,{slots:e}){return()=>{const{clsPrefix:t}=r;return p(en,{clsPrefix:t,class:`${t}-base-suffix`,strokeWidth:24,scale:.85,show:r.loading},{default:()=>r.showArrow?p(rr,{clsPrefix:t,show:r.showClear,onClear:r.onClear},{placeholder:()=>p(Ne,{clsPrefix:t,class:`${t}-base-suffix__arrow`},{default:()=>Oe(e.default,()=>[p(bn,null)])})}):null})}}}),kn={paddingTiny:"0 8px",paddingSmall:"0 10px",paddingMedium:"0 12px",paddingLarge:"0 14px",clearSize:"16px"};function Fn(r){const{textColor2:e,textColor3:t,textColorDisabled:n,primaryColor:a,primaryColorHover:l,inputColor:s,inputColorDisabled:o,borderColor:u,warningColor:m,warningColorHover:c,errorColor:g,errorColorHover:x,borderRadius:C,lineHeight:f,fontSizeTiny:h,fontSizeSmall:w,fontSizeMedium:v,fontSizeLarge:L,heightTiny:b,heightSmall:k,heightMedium:R,heightLarge:M,actionColor:J,clearColor:W,clearColorHover:Y,clearColorPressed:G,placeholderColor:te,placeholderColorDisabled:N,iconColor:T,iconColorDisabled:fe,iconColorHover:P,iconColorPressed:D,fontWeight:Q}=r;return Object.assign(Object.assign({},kn),{fontWeight:Q,countTextColorDisabled:n,countTextColor:t,heightTiny:b,heightSmall:k,heightMedium:R,heightLarge:M,fontSizeTiny:h,fontSizeSmall:w,fontSizeMedium:v,fontSizeLarge:L,lineHeight:f,lineHeightTextarea:f,borderRadius:C,iconSize:"16px",groupLabelColor:J,groupLabelTextColor:e,textColor:e,textColorDisabled:n,textDecorationColor:e,caretColor:a,placeholderColor:te,placeholderColorDisabled:N,color:s,colorDisabled:o,colorFocus:s,groupLabelBorder:`1px solid ${u}`,border:`1px solid ${u}`,borderHover:`1px solid ${l}`,borderDisabled:`1px solid ${u}`,borderFocus:`1px solid ${l}`,boxShadowFocus:`0 0 0 2px ${Xe(a,{alpha:.2})}`,loadingColor:a,loadingColorWarning:m,borderWarning:`1px solid ${m}`,borderHoverWarning:`1px solid ${c}`,colorFocusWarning:s,borderFocusWarning:`1px solid ${c}`,boxShadowFocusWarning:`0 0 0 2px ${Xe(m,{alpha:.2})}`,caretColorWarning:m,loadingColorError:g,borderError:`1px solid ${g}`,borderHoverError:`1px solid ${x}`,colorFocusError:s,borderFocusError:`1px solid ${x}`,boxShadowFocusError:`0 0 0 2px ${Xe(g,{alpha:.2})}`,caretColorError:g,clearColor:W,clearColorHover:Y,clearColorPressed:G,iconColor:T,iconColorDisabled:fe,iconColorHover:P,iconColorPressed:D,suffixTextColor:e})}const Rn=rn({name:"Input",common:zr,peers:{Scrollbar:tn},self:Fn}),Mr=lr("n-input"),_n=_("input",`
 max-width: 100%;
 cursor: text;
 line-height: 1.5;
 z-index: auto;
 outline: none;
 box-sizing: border-box;
 position: relative;
 display: inline-flex;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 font-weight: var(--n-font-weight);
 --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);
`,[S("input, textarea",`
 overflow: hidden;
 flex-grow: 1;
 position: relative;
 `),S("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder",`
 box-sizing: border-box;
 font-size: inherit;
 line-height: 1.5;
 font-family: inherit;
 border: none;
 outline: none;
 background-color: #0000;
 text-align: inherit;
 transition:
 -webkit-text-fill-color .3s var(--n-bezier),
 caret-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier);
 `),S("input-el, textarea-el",`
 -webkit-appearance: none;
 scrollbar-width: none;
 width: 100%;
 min-width: 0;
 text-decoration-color: var(--n-text-decoration-color);
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 background-color: transparent;
 `,[V("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `),V("&::placeholder",`
 color: #0000;
 -webkit-text-fill-color: transparent !important;
 `),V("&:-webkit-autofill ~",[S("placeholder","display: none;")])]),B("round",[ze("textarea","border-radius: calc(var(--n-height) / 2);")]),S("placeholder",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 overflow: hidden;
 color: var(--n-placeholder-color);
 `,[V("span",`
 width: 100%;
 display: inline-block;
 `)]),B("textarea",[S("placeholder","overflow: visible;")]),ze("autosize","width: 100%;"),B("autosize",[S("textarea-el, input-el",`
 position: absolute;
 top: 0;
 left: 0;
 height: 100%;
 `)]),_("input-wrapper",`
 overflow: hidden;
 display: inline-flex;
 flex-grow: 1;
 position: relative;
 padding-left: var(--n-padding-left);
 padding-right: var(--n-padding-right);
 `),S("input-mirror",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre;
 pointer-events: none;
 `),S("input-el",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 `,[V("&[type=password]::-ms-reveal","display: none;"),V("+",[S("placeholder",`
 display: flex;
 align-items: center; 
 `)])]),ze("textarea",[S("placeholder","white-space: nowrap;")]),S("eye",`
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `),B("textarea","width: 100%;",[_("input-word-count",`
 position: absolute;
 right: var(--n-padding-right);
 bottom: var(--n-padding-vertical);
 `),B("resizable",[_("input-wrapper",`
 resize: vertical;
 min-height: var(--n-height);
 `)]),S("textarea-el, textarea-mirror, placeholder",`
 height: 100%;
 padding-left: 0;
 padding-right: 0;
 padding-top: var(--n-padding-vertical);
 padding-bottom: var(--n-padding-vertical);
 word-break: break-word;
 display: inline-block;
 vertical-align: bottom;
 box-sizing: border-box;
 line-height: var(--n-line-height-textarea);
 margin: 0;
 resize: none;
 white-space: pre-wrap;
 scroll-padding-block-end: var(--n-padding-vertical);
 `),S("textarea-mirror",`
 width: 100%;
 pointer-events: none;
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre-wrap;
 overflow-wrap: break-word;
 `)]),B("pair",[S("input-el, placeholder","text-align: center;"),S("separator",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 white-space: nowrap;
 `,[_("icon",`
 color: var(--n-icon-color);
 `),_("base-icon",`
 color: var(--n-icon-color);
 `)])]),B("disabled",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[S("border","border: var(--n-border-disabled);"),S("input-el, textarea-el",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 text-decoration-color: var(--n-text-color-disabled);
 `),S("placeholder","color: var(--n-placeholder-color-disabled);"),S("separator","color: var(--n-text-color-disabled);",[_("icon",`
 color: var(--n-icon-color-disabled);
 `),_("base-icon",`
 color: var(--n-icon-color-disabled);
 `)]),_("input-word-count",`
 color: var(--n-count-text-color-disabled);
 `),S("suffix, prefix","color: var(--n-text-color-disabled);",[_("icon",`
 color: var(--n-icon-color-disabled);
 `),_("internal-icon",`
 color: var(--n-icon-color-disabled);
 `)])]),ze("disabled",[S("eye",`
 color: var(--n-icon-color);
 cursor: pointer;
 `,[V("&:hover",`
 color: var(--n-icon-color-hover);
 `),V("&:active",`
 color: var(--n-icon-color-pressed);
 `)]),V("&:hover",[S("state-border","border: var(--n-border-hover);")]),B("focus","background-color: var(--n-color-focus);",[S("state-border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),S("border, state-border",`
 box-sizing: border-box;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: inherit;
 border: var(--n-border);
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),S("state-border",`
 border-color: #0000;
 z-index: 1;
 `),S("prefix","margin-right: 4px;"),S("suffix",`
 margin-left: 4px;
 `),S("suffix, prefix",`
 transition: color .3s var(--n-bezier);
 flex-wrap: nowrap;
 flex-shrink: 0;
 line-height: var(--n-height);
 white-space: nowrap;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-suffix-text-color);
 `,[_("base-loading",`
 font-size: var(--n-icon-size);
 margin: 0 2px;
 color: var(--n-loading-color);
 `),_("base-clear",`
 font-size: var(--n-icon-size);
 `,[S("placeholder",[_("base-icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)])]),V(">",[_("icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)]),_("base-icon",`
 font-size: var(--n-icon-size);
 `)]),_("input-word-count",`
 pointer-events: none;
 line-height: 1.5;
 font-size: .85em;
 color: var(--n-count-text-color);
 transition: color .3s var(--n-bezier);
 margin-left: 4px;
 font-variant: tabular-nums;
 `),["warning","error"].map(r=>B(`${r}-status`,[ze("disabled",[_("base-loading",`
 color: var(--n-loading-color-${r})
 `),S("input-el, textarea-el",`
 caret-color: var(--n-caret-color-${r});
 `),S("state-border",`
 border: var(--n-border-${r});
 `),V("&:hover",[S("state-border",`
 border: var(--n-border-hover-${r});
 `)]),V("&:focus",`
 background-color: var(--n-color-focus-${r});
 `,[S("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)]),B("focus",`
 background-color: var(--n-color-focus-${r});
 `,[S("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)])])]))]),$n=_("input",[B("disabled",[S("input-el, textarea-el",`
 -webkit-text-fill-color: var(--n-text-color-disabled);
 `)])]);function Pn(r){let e=0;for(const t of r)e++;return e}function je(r){return r===""||r==null}function zn(r){const e=I(null);function t(){const{value:l}=r;if(!l?.focus){a();return}const{selectionStart:s,selectionEnd:o,value:u}=l;if(s==null||o==null){a();return}e.value={start:s,end:o,beforeText:u.slice(0,s),afterText:u.slice(o)}}function n(){var l;const{value:s}=e,{value:o}=r;if(!s||!o)return;const{value:u}=o,{start:m,beforeText:c,afterText:g}=s;let x=u.length;if(u.endsWith(g))x=u.length-g.length;else if(u.startsWith(c))x=c.length;else{const C=c[m-1],f=u.indexOf(C,m-1);f!==-1&&(x=f+1)}(l=o.setSelectionRange)===null||l===void 0||l.call(o,x,x)}function a(){e.value=null}return qe(r,a),{recordCursor:t,restoreCursor:n}}const yr=se({name:"InputWordCount",setup(r,{slots:e}){const{mergedValueRef:t,maxlengthRef:n,mergedClsPrefixRef:a,countGraphemesRef:l}=Re(Mr),s=O(()=>{const{value:o}=t;return o===null||Array.isArray(o)?0:(l.value||Pn)(o)});return()=>{const{value:o}=n,{value:u}=t;return p("span",{class:`${a.value}-input-word-count`},nn(e.default,{value:u===null||Array.isArray(u)?"":u},()=>[o===void 0?s.value:`${s.value} / ${o}`]))}}}),An=Object.assign(Object.assign({},_e.props),{bordered:{type:Boolean,default:void 0},type:{type:String,default:"text"},placeholder:[Array,String],defaultValue:{type:[String,Array],default:null},value:[String,Array],disabled:{type:Boolean,default:void 0},size:String,rows:{type:[Number,String],default:3},round:Boolean,minlength:[String,Number],maxlength:[String,Number],clearable:Boolean,autosize:{type:[Boolean,Object],default:!1},pair:Boolean,separator:String,readonly:{type:[String,Boolean],default:!1},passivelyActivated:Boolean,showPasswordOn:String,stateful:{type:Boolean,default:!0},autofocus:Boolean,inputProps:Object,resizable:{type:Boolean,default:!0},showCount:Boolean,loading:{type:Boolean,default:void 0},allowInput:Function,renderCount:Function,onMousedown:Function,onKeydown:Function,onKeyup:[Function,Array],onInput:[Function,Array],onFocus:[Function,Array],onBlur:[Function,Array],onClick:[Function,Array],onChange:[Function,Array],onClear:[Function,Array],countGraphemes:Function,status:String,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],textDecoration:[String,Array],attrSize:{type:Number,default:20},onInputBlur:[Function,Array],onInputFocus:[Function,Array],onDeactivate:[Function,Array],onActivate:[Function,Array],onWrapperFocus:[Function,Array],onWrapperBlur:[Function,Array],internalDeactivateOnEnter:Boolean,internalForceFocus:Boolean,internalLoadingBeforeSuffix:{type:Boolean,default:!0},showPasswordToggle:Boolean}),ki=se({name:"Input",props:An,slots:Object,setup(r){const{mergedClsPrefixRef:e,mergedBorderedRef:t,inlineThemeDisabled:n,mergedRtlRef:a,mergedComponentPropsRef:l}=Ue(r),s=_e("Input","-input",_n,Rn,r,e);sn&&Pr("-input-safari",$n,e);const o=I(null),u=I(null),m=I(null),c=I(null),g=I(null),x=I(null),C=I(null),f=zn(C),h=I(null),{localeRef:w}=vn("Input"),v=I(r.defaultValue),L=me(r,"value"),b=pn(L,v),k=dn(r,{mergedSize:i=>{var d,y;const{size:z}=r;if(z)return z;const{mergedSize:E}=i||{};if(E?.value)return E.value;const $=(y=(d=l?.value)===null||d===void 0?void 0:d.Input)===null||y===void 0?void 0:y.size;return $||"medium"}}),{mergedSizeRef:R,mergedDisabledRef:M,mergedStatusRef:J}=k,W=I(!1),Y=I(!1),G=I(!1),te=I(!1);let N=null;const T=O(()=>{const{placeholder:i,pair:d}=r;return d?Array.isArray(i)?i:i===void 0?["",""]:[i,i]:i===void 0?[w.value.placeholder]:[i]}),fe=O(()=>{const{value:i}=G,{value:d}=b,{value:y}=T;return!i&&(je(d)||Array.isArray(d)&&je(d[0]))&&y[0]}),P=O(()=>{const{value:i}=G,{value:d}=b,{value:y}=T;return!i&&y[1]&&(je(d)||Array.isArray(d)&&je(d[1]))}),D=fr(()=>r.internalForceFocus||W.value),Q=fr(()=>{if(M.value||r.readonly||!r.clearable||!D.value&&!Y.value)return!1;const{value:i}=b,{value:d}=D;return r.pair?!!(Array.isArray(i)&&(i[0]||i[1]))&&(Y.value||d):!!i&&(Y.value||d)}),j=O(()=>{const{showPasswordOn:i}=r;if(i)return i;if(r.showPasswordToggle)return"click"}),Z=I(!1),ae=O(()=>{const{textDecoration:i}=r;return i?Array.isArray(i)?i.map(d=>({textDecoration:d})):[{textDecoration:i}]:["",""]}),oe=I(void 0),de=()=>{var i,d;if(r.type==="textarea"){const{autosize:y}=r;if(y&&(oe.value=(d=(i=h.value)===null||i===void 0?void 0:i.$el)===null||d===void 0?void 0:d.offsetWidth),!u.value||typeof y=="boolean")return;const{paddingTop:z,paddingBottom:E,lineHeight:$}=window.getComputedStyle(u.value),ge=Number(z.slice(0,-2)),ve=Number(E.slice(0,-2)),pe=Number($.slice(0,-2)),{value:$e}=m;if(!$e)return;if(y.minRows){const Pe=Math.max(y.minRows,1),Ze=`${ge+ve+pe*Pe}px`;$e.style.minHeight=Ze}if(y.maxRows){const Pe=`${ge+ve+pe*y.maxRows}px`;$e.style.maxHeight=Pe}}},ue=O(()=>{const{maxlength:i}=r;return i===void 0?void 0:Number(i)});Ar(()=>{const{value:i}=b;Array.isArray(i)||Ge(i)});const ie=$r().proxy;function ee(i,d){const{onUpdateValue:y,"onUpdate:value":z,onInput:E}=r,{nTriggerFormInput:$}=k;y&&U(y,i,d),z&&U(z,i,d),E&&U(E,i,d),v.value=i,$()}function le(i,d){const{onChange:y}=r,{nTriggerFormChange:z}=k;y&&U(y,i,d),v.value=i,z()}function X(i){const{onBlur:d}=r,{nTriggerFormBlur:y}=k;d&&U(d,i),y()}function ce(i){const{onFocus:d}=r,{nTriggerFormFocus:y}=k;d&&U(d,i),y()}function ye(i){const{onClear:d}=r;d&&U(d,i)}function xe(i){const{onInputBlur:d}=r;d&&U(d,i)}function he(i){const{onInputFocus:d}=r;d&&U(d,i)}function we(){const{onDeactivate:i}=r;i&&U(i)}function A(){const{onActivate:i}=r;i&&U(i)}function K(i){const{onClick:d}=r;d&&U(d,i)}function q(i){const{onWrapperFocus:d}=r;d&&U(d,i)}function Ce(i){const{onWrapperBlur:d}=r;d&&U(d,i)}function Tr(){G.value=!0}function Br(i){G.value=!1,i.target===x.value?Te(i,1):Te(i,0)}function Te(i,d=0,y="input"){const z=i.target.value;if(Ge(z),i instanceof InputEvent&&!i.isComposing&&(G.value=!1),r.type==="textarea"){const{value:$}=h;$&&$.syncUnifiedContainer()}if(N=z,G.value)return;f.recordCursor();const E=Vr(z);if(E)if(!r.pair)y==="input"?ee(z,{source:d}):le(z,{source:d});else{let{value:$}=b;Array.isArray($)?$=[$[0],$[1]]:$=["",""],$[d]=z,y==="input"?ee($,{source:d}):le($,{source:d})}ie.$forceUpdate(),E||gr(f.restoreCursor)}function Vr(i){const{countGraphemes:d,maxlength:y,minlength:z}=r;if(d){let $;if(y!==void 0&&($===void 0&&($=d(i)),$>Number(y))||z!==void 0&&($===void 0&&($=d(i)),$<Number(y)))return!1}const{allowInput:E}=r;return typeof E=="function"?E(i):!0}function Wr(i){xe(i),i.relatedTarget===o.value&&we(),i.relatedTarget!==null&&(i.relatedTarget===g.value||i.relatedTarget===x.value||i.relatedTarget===u.value)||(te.value=!1),Be(i,"blur"),C.value=null}function jr(i,d){he(i),W.value=!0,te.value=!0,A(),Be(i,"focus"),d===0?C.value=g.value:d===1?C.value=x.value:d===2&&(C.value=u.value)}function Dr(i){r.passivelyActivated&&(Ce(i),Be(i,"blur"))}function Hr(i){r.passivelyActivated&&(W.value=!0,q(i),Be(i,"focus"))}function Be(i,d){i.relatedTarget!==null&&(i.relatedTarget===g.value||i.relatedTarget===x.value||i.relatedTarget===u.value||i.relatedTarget===o.value)||(d==="focus"?(ce(i),W.value=!0):d==="blur"&&(X(i),W.value=!1))}function Nr(i,d){Te(i,d,"change")}function Kr(i){K(i)}function Ur(i){ye(i),sr()}function sr(){r.pair?(ee(["",""],{source:"clear"}),le(["",""],{source:"clear"})):(ee("",{source:"clear"}),le("",{source:"clear"}))}function Yr(i){const{onMousedown:d}=r;d&&d(i);const{tagName:y}=i.target;if(y!=="INPUT"&&y!=="TEXTAREA"){if(r.resizable){const{value:z}=o;if(z){const{left:E,top:$,width:ge,height:ve}=z.getBoundingClientRect(),pe=14;if(E+ge-pe<i.clientX&&i.clientX<E+ge&&$+ve-pe<i.clientY&&i.clientY<$+ve)return}}i.preventDefault(),W.value||dr()}}function Gr(){var i;Y.value=!0,r.type==="textarea"&&((i=h.value)===null||i===void 0||i.handleMouseEnterWrapper())}function Zr(){var i;Y.value=!1,r.type==="textarea"&&((i=h.value)===null||i===void 0||i.handleMouseLeaveWrapper())}function Xr(){M.value||j.value==="click"&&(Z.value=!Z.value)}function Jr(i){if(M.value)return;i.preventDefault();const d=z=>{z.preventDefault(),pr("mouseup",document,d)};if(vr("mouseup",document,d),j.value!=="mousedown")return;Z.value=!0;const y=()=>{Z.value=!1,pr("mouseup",document,y)};vr("mouseup",document,y)}function Qr(i){r.onKeyup&&U(r.onKeyup,i)}function et(i){switch(r.onKeydown&&U(r.onKeydown,i),i.key){case"Escape":Ye();break;case"Enter":rt(i);break}}function rt(i){var d,y;if(r.passivelyActivated){const{value:z}=te;if(z){r.internalDeactivateOnEnter&&Ye();return}i.preventDefault(),r.type==="textarea"?(d=u.value)===null||d===void 0||d.focus():(y=g.value)===null||y===void 0||y.focus()}}function Ye(){r.passivelyActivated&&(te.value=!1,gr(()=>{var i;(i=o.value)===null||i===void 0||i.focus()}))}function dr(){var i,d,y;M.value||(r.passivelyActivated?(i=o.value)===null||i===void 0||i.focus():((d=u.value)===null||d===void 0||d.focus(),(y=g.value)===null||y===void 0||y.focus()))}function tt(){var i;!((i=o.value)===null||i===void 0)&&i.contains(document.activeElement)&&document.activeElement.blur()}function nt(){var i,d;(i=u.value)===null||i===void 0||i.select(),(d=g.value)===null||d===void 0||d.select()}function it(){M.value||(u.value?u.value.focus():g.value&&g.value.focus())}function at(){const{value:i}=o;i?.contains(document.activeElement)&&i!==document.activeElement&&Ye()}function ot(i){if(r.type==="textarea"){const{value:d}=u;d?.scrollTo(i)}else{const{value:d}=g;d?.scrollTo(i)}}function Ge(i){const{type:d,pair:y,autosize:z}=r;if(!y&&z)if(d==="textarea"){const{value:E}=m;E&&(E.textContent=`${i??""}\r
`)}else{const{value:E}=c;E&&(i?E.textContent=i:E.innerHTML="&nbsp;")}}function lt(){de()}const ur=I({top:"0"});function st(i){var d;const{scrollTop:y}=i.target;ur.value.top=`${-y}px`,(d=h.value)===null||d===void 0||d.syncUnifiedContainer()}let Ve=null;hr(()=>{const{autosize:i,type:d}=r;i&&d==="textarea"?Ve=qe(b,y=>{!Array.isArray(y)&&y!==N&&Ge(y)}):Ve?.()});let We=null;hr(()=>{r.type==="textarea"?We=qe(b,i=>{var d;!Array.isArray(i)&&i!==N&&((d=h.value)===null||d===void 0||d.syncUnifiedContainer())}):We?.()}),Ke(Mr,{mergedValueRef:b,maxlengthRef:ue,mergedClsPrefixRef:e,countGraphemesRef:me(r,"countGraphemes")});const dt={wrapperElRef:o,inputElRef:g,textareaElRef:u,isCompositing:G,clear:sr,focus:dr,blur:tt,select:nt,deactivate:at,activate:it,scrollTo:ot},ut=un("Input",a,e),cr=O(()=>{const{value:i}=R,{common:{cubicBezierEaseInOut:d},self:{color:y,borderRadius:z,textColor:E,caretColor:$,caretColorError:ge,caretColorWarning:ve,textDecorationColor:pe,border:$e,borderDisabled:Pe,borderHover:Ze,borderFocus:ct,placeholderColor:ft,placeholderColorDisabled:ht,lineHeightTextarea:gt,colorDisabled:vt,colorFocus:pt,textColorDisabled:mt,boxShadowFocus:bt,iconSize:yt,colorFocusWarning:xt,boxShadowFocusWarning:wt,borderWarning:Ct,borderFocusWarning:St,borderHoverWarning:kt,colorFocusError:Ft,boxShadowFocusError:Rt,borderError:_t,borderFocusError:$t,borderHoverError:Pt,clearSize:zt,clearColor:At,clearColorHover:Et,clearColorPressed:Ot,iconColor:Mt,iconColorDisabled:qt,suffixTextColor:It,countTextColor:Lt,countTextColorDisabled:Tt,iconColorHover:Bt,iconColorPressed:Vt,loadingColor:Wt,loadingColorError:jt,loadingColorWarning:Dt,fontWeight:Ht,[ne("padding",i)]:Nt,[ne("fontSize",i)]:Kt,[ne("height",i)]:Ut}}=s.value,{left:Yt,right:Gt}=cn(Nt);return{"--n-bezier":d,"--n-count-text-color":Lt,"--n-count-text-color-disabled":Tt,"--n-color":y,"--n-font-size":Kt,"--n-font-weight":Ht,"--n-border-radius":z,"--n-height":Ut,"--n-padding-left":Yt,"--n-padding-right":Gt,"--n-text-color":E,"--n-caret-color":$,"--n-text-decoration-color":pe,"--n-border":$e,"--n-border-disabled":Pe,"--n-border-hover":Ze,"--n-border-focus":ct,"--n-placeholder-color":ft,"--n-placeholder-color-disabled":ht,"--n-icon-size":yt,"--n-line-height-textarea":gt,"--n-color-disabled":vt,"--n-color-focus":pt,"--n-text-color-disabled":mt,"--n-box-shadow-focus":bt,"--n-loading-color":Wt,"--n-caret-color-warning":ve,"--n-color-focus-warning":xt,"--n-box-shadow-focus-warning":wt,"--n-border-warning":Ct,"--n-border-focus-warning":St,"--n-border-hover-warning":kt,"--n-loading-color-warning":Dt,"--n-caret-color-error":ge,"--n-color-focus-error":Ft,"--n-box-shadow-focus-error":Rt,"--n-border-error":_t,"--n-border-focus-error":$t,"--n-border-hover-error":Pt,"--n-loading-color-error":jt,"--n-clear-color":At,"--n-clear-size":zt,"--n-clear-color-hover":Et,"--n-clear-color-pressed":Ot,"--n-icon-color":Mt,"--n-icon-color-hover":Bt,"--n-icon-color-pressed":Vt,"--n-icon-color-disabled":qt,"--n-suffix-text-color":It}}),Se=n?Er("input",O(()=>{const{value:i}=R;return i[0]}),cr,r):void 0;return Object.assign(Object.assign({},dt),{wrapperElRef:o,inputElRef:g,inputMirrorElRef:c,inputEl2Ref:x,textareaElRef:u,textareaMirrorElRef:m,textareaScrollbarInstRef:h,rtlEnabled:ut,uncontrolledValue:v,mergedValue:b,passwordVisible:Z,mergedPlaceholder:T,showPlaceholder1:fe,showPlaceholder2:P,mergedFocus:D,isComposing:G,activated:te,showClearButton:Q,mergedSize:R,mergedDisabled:M,textDecorationStyle:ae,mergedClsPrefix:e,mergedBordered:t,mergedShowPasswordOn:j,placeholderStyle:ur,mergedStatus:J,textAreaScrollContainerWidth:oe,handleTextAreaScroll:st,handleCompositionStart:Tr,handleCompositionEnd:Br,handleInput:Te,handleInputBlur:Wr,handleInputFocus:jr,handleWrapperBlur:Dr,handleWrapperFocus:Hr,handleMouseEnter:Gr,handleMouseLeave:Zr,handleMouseDown:Yr,handleChange:Nr,handleClick:Kr,handleClear:Ur,handlePasswordToggleClick:Xr,handlePasswordToggleMousedown:Jr,handleWrapperKeydown:et,handleWrapperKeyup:Qr,handleTextAreaMirrorResize:lt,getTextareaScrollContainer:()=>u.value,mergedTheme:s,cssVars:n?void 0:cr,themeClass:Se?.themeClass,onRender:Se?.onRender})},render(){var r,e,t,n,a,l,s;const{mergedClsPrefix:o,mergedStatus:u,themeClass:m,type:c,countGraphemes:g,onRender:x}=this,C=this.$slots;return x?.(),p("div",{ref:"wrapperElRef",class:[`${o}-input`,`${o}-input--${this.mergedSize}-size`,m,u&&`${o}-input--${u}-status`,{[`${o}-input--rtl`]:this.rtlEnabled,[`${o}-input--disabled`]:this.mergedDisabled,[`${o}-input--textarea`]:c==="textarea",[`${o}-input--resizable`]:this.resizable&&!this.autosize,[`${o}-input--autosize`]:this.autosize,[`${o}-input--round`]:this.round&&c!=="textarea",[`${o}-input--pair`]:this.pair,[`${o}-input--focus`]:this.mergedFocus,[`${o}-input--stateful`]:this.stateful}],style:this.cssVars,tabindex:!this.mergedDisabled&&this.passivelyActivated&&!this.activated?0:void 0,onFocus:this.handleWrapperFocus,onBlur:this.handleWrapperBlur,onClick:this.handleClick,onMousedown:this.handleMouseDown,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd,onKeyup:this.handleWrapperKeyup,onKeydown:this.handleWrapperKeydown},p("div",{class:`${o}-input-wrapper`},Ae(C.prefix,f=>f&&p("div",{class:`${o}-input__prefix`},f)),c==="textarea"?p(an,{ref:"textareaScrollbarInstRef",class:`${o}-input__textarea`,container:this.getTextareaScrollContainer,theme:(e=(r=this.theme)===null||r===void 0?void 0:r.peers)===null||e===void 0?void 0:e.Scrollbar,themeOverrides:(n=(t=this.themeOverrides)===null||t===void 0?void 0:t.peers)===null||n===void 0?void 0:n.Scrollbar,triggerDisplayManually:!0,useUnifiedContainer:!0,internalHoistYRail:!0},{default:()=>{var f,h;const{textAreaScrollContainerWidth:w}=this,v={width:this.autosize&&w&&`${w}px`};return p(on,null,p("textarea",Object.assign({},this.inputProps,{ref:"textareaElRef",class:[`${o}-input__textarea-el`,(f=this.inputProps)===null||f===void 0?void 0:f.class],autofocus:this.autofocus,rows:Number(this.rows),placeholder:this.placeholder,value:this.mergedValue,disabled:this.mergedDisabled,maxlength:g?void 0:this.maxlength,minlength:g?void 0:this.minlength,readonly:this.readonly,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,style:[this.textDecorationStyle[0],(h=this.inputProps)===null||h===void 0?void 0:h.style,v],onBlur:this.handleInputBlur,onFocus:L=>{this.handleInputFocus(L,2)},onInput:this.handleInput,onChange:this.handleChange,onScroll:this.handleTextAreaScroll})),this.showPlaceholder1?p("div",{class:`${o}-input__placeholder`,style:[this.placeholderStyle,v],key:"placeholder"},this.mergedPlaceholder[0]):null,this.autosize?p(ln,{onResize:this.handleTextAreaMirrorResize},{default:()=>p("div",{ref:"textareaMirrorElRef",class:`${o}-input__textarea-mirror`,key:"mirror"})}):null)}}):p("div",{class:`${o}-input__input`},p("input",Object.assign({type:c==="password"&&this.mergedShowPasswordOn&&this.passwordVisible?"text":c},this.inputProps,{ref:"inputElRef",class:[`${o}-input__input-el`,(a=this.inputProps)===null||a===void 0?void 0:a.class],style:[this.textDecorationStyle[0],(l=this.inputProps)===null||l===void 0?void 0:l.style],tabindex:this.passivelyActivated&&!this.activated?-1:(s=this.inputProps)===null||s===void 0?void 0:s.tabindex,placeholder:this.mergedPlaceholder[0],disabled:this.mergedDisabled,maxlength:g?void 0:this.maxlength,minlength:g?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[0]:this.mergedValue,readonly:this.readonly,autofocus:this.autofocus,size:this.attrSize,onBlur:this.handleInputBlur,onFocus:f=>{this.handleInputFocus(f,0)},onInput:f=>{this.handleInput(f,0)},onChange:f=>{this.handleChange(f,0)}})),this.showPlaceholder1?p("div",{class:`${o}-input__placeholder`},p("span",null,this.mergedPlaceholder[0])):null,this.autosize?p("div",{class:`${o}-input__input-mirror`,key:"mirror",ref:"inputMirrorElRef"}," "):null),!this.pair&&Ae(C.suffix,f=>f||this.clearable||this.showCount||this.mergedShowPasswordOn||this.loading!==void 0?p("div",{class:`${o}-input__suffix`},[Ae(C["clear-icon-placeholder"],h=>(this.clearable||h)&&p(rr,{clsPrefix:o,show:this.showClearButton,onClear:this.handleClear},{placeholder:()=>h,icon:()=>{var w,v;return(v=(w=this.$slots)["clear-icon"])===null||v===void 0?void 0:v.call(w)}})),this.internalLoadingBeforeSuffix?null:f,this.loading!==void 0?p(Sn,{clsPrefix:o,loading:this.loading,showArrow:!1,showClear:!1,style:this.cssVars}):null,this.internalLoadingBeforeSuffix?f:null,this.showCount&&this.type!=="textarea"?p(yr,null,{default:h=>{var w;const{renderCount:v}=this;return v?v(h):(w=C.count)===null||w===void 0?void 0:w.call(C,h)}}):null,this.mergedShowPasswordOn&&this.type==="password"?p("div",{class:`${o}-input__eye`,onMousedown:this.handlePasswordToggleMousedown,onClick:this.handlePasswordToggleClick},this.passwordVisible?Oe(C["password-visible-icon"],()=>[p(Ne,{clsPrefix:o},{default:()=>p(xn,null)})]):Oe(C["password-invisible-icon"],()=>[p(Ne,{clsPrefix:o},{default:()=>p(wn,null)})])):null]):null)),this.pair?p("span",{class:`${o}-input__separator`},Oe(C.separator,()=>[this.separator])):null,this.pair?p("div",{class:`${o}-input-wrapper`},p("div",{class:`${o}-input__input`},p("input",{ref:"inputEl2Ref",type:this.type,class:`${o}-input__input-el`,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[1],disabled:this.mergedDisabled,maxlength:g?void 0:this.maxlength,minlength:g?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[1]:void 0,readonly:this.readonly,style:this.textDecorationStyle[1],onBlur:this.handleInputBlur,onFocus:f=>{this.handleInputFocus(f,1)},onInput:f=>{this.handleInput(f,1)},onChange:f=>{this.handleChange(f,1)}}),this.showPlaceholder2?p("div",{class:`${o}-input__placeholder`},p("span",null,this.mergedPlaceholder[1])):null),Ae(C.suffix,f=>(this.clearable||f)&&p("div",{class:`${o}-input__suffix`},[this.clearable&&p(rr,{clsPrefix:o,show:this.showClearButton,onClear:this.handleClear},{icon:()=>{var h;return(h=C["clear-icon"])===null||h===void 0?void 0:h.call(C)},placeholder:()=>{var h;return(h=C["clear-icon-placeholder"])===null||h===void 0?void 0:h.call(C)}}),f]))):null,this.mergedBordered?p("div",{class:`${o}-input__border`}):null,this.mergedBordered?p("div",{class:`${o}-input__state-border`}):null,this.showCount&&c==="textarea"?p(yr,null,{default:f=>{var h;const{renderCount:w}=this;return w?w(f):(h=C.count)===null||h===void 0?void 0:h.call(C,f)}}):null)}}),En={feedbackPadding:"4px 0 0 2px",feedbackHeightSmall:"24px",feedbackHeightMedium:"24px",feedbackHeightLarge:"26px",feedbackFontSizeSmall:"13px",feedbackFontSizeMedium:"14px",feedbackFontSizeLarge:"14px",labelFontSizeLeftSmall:"14px",labelFontSizeLeftMedium:"14px",labelFontSizeLeftLarge:"15px",labelFontSizeTopSmall:"13px",labelFontSizeTopMedium:"14px",labelFontSizeTopLarge:"14px",labelHeightSmall:"24px",labelHeightMedium:"26px",labelHeightLarge:"28px",labelPaddingVertical:"0 0 6px 2px",labelPaddingHorizontal:"0 12px 0 0",labelTextAlignVertical:"left",labelTextAlignHorizontal:"right",labelFontWeight:"400"};function On(r){const{heightSmall:e,heightMedium:t,heightLarge:n,textColor1:a,errorColor:l,warningColor:s,lineHeight:o,textColor3:u}=r;return Object.assign(Object.assign({},En),{blankHeightSmall:e,blankHeightMedium:t,blankHeightLarge:n,lineHeight:o,labelTextColor:a,asteriskColor:l,feedbackTextColorError:l,feedbackTextColorWarning:s,feedbackTextColor:u})}const qr={common:zr,self:On},Le=lr("n-form"),Ir=lr("n-form-item-insts"),Mn=_("form",[B("inline",`
 width: 100%;
 display: inline-flex;
 align-items: flex-start;
 align-content: space-around;
 `,[_("form-item",{width:"auto",marginRight:"18px"},[V("&:last-child",{marginRight:0})])])]);var qn=function(r,e,t,n){function a(l){return l instanceof t?l:new t(function(s){s(l)})}return new(t||(t=Promise))(function(l,s){function o(c){try{m(n.next(c))}catch(g){s(g)}}function u(c){try{m(n.throw(c))}catch(g){s(g)}}function m(c){c.done?l(c.value):a(c.value).then(o,u)}m((n=n.apply(r,e||[])).next())})};const In=Object.assign(Object.assign({},_e.props),{inline:Boolean,labelWidth:[Number,String],labelAlign:String,labelPlacement:{type:String,default:"top"},model:{type:Object,default:()=>{}},rules:Object,disabled:Boolean,size:String,showRequireMark:{type:Boolean,default:void 0},requireMarkPlacement:String,showFeedback:{type:Boolean,default:!0},onSubmit:{type:Function,default:r=>{r.preventDefault()}},showLabel:{type:Boolean,default:void 0},validateMessages:Object}),Fi=se({name:"Form",props:In,setup(r){const{mergedClsPrefixRef:e}=Ue(r);_e("Form","-form",Mn,qr,r,e);const t={},n=I(void 0),a=m=>{const c=n.value;(c===void 0||m>=c)&&(n.value=m)};function l(){var m;for(const c of Je(t)){const g=t[c];for(const x of g)(m=x.invalidateLabelWidth)===null||m===void 0||m.call(x)}}function s(m){return qn(this,arguments,void 0,function*(c,g=()=>!0){return yield new Promise((x,C)=>{const f=[];for(const h of Je(t)){const w=t[h];for(const v of w)v.path&&f.push(v.internalValidate(null,g))}Promise.all(f).then(h=>{const w=h.some(b=>!b.valid),v=[],L=[];h.forEach(b=>{var k,R;!((k=b.errors)===null||k===void 0)&&k.length&&v.push(b.errors),!((R=b.warnings)===null||R===void 0)&&R.length&&L.push(b.warnings)}),c&&c(v.length?v:void 0,{warnings:L.length?L:void 0}),w?C(v.length?v:void 0):x({warnings:L.length?L:void 0})})})})}function o(){for(const m of Je(t)){const c=t[m];for(const g of c)g.restoreValidation()}}return Ke(Le,{props:r,maxChildLabelWidthRef:n,deriveMaxChildLabelWidth:a}),Ke(Ir,{formItems:t}),Object.assign({validate:s,restoreValidation:o,invalidateLabelWidth:l},{mergedClsPrefix:e})},render(){const{mergedClsPrefix:r}=this;return p("form",{class:[`${r}-form`,this.inline&&`${r}-form--inline`],onSubmit:this.onSubmit},this.$slots)}});function be(){return be=Object.assign?Object.assign.bind():function(r){for(var e=1;e<arguments.length;e++){var t=arguments[e];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(r[n]=t[n])}return r},be.apply(this,arguments)}function Ln(r,e){r.prototype=Object.create(e.prototype),r.prototype.constructor=r,Ie(r,e)}function tr(r){return tr=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(t){return t.__proto__||Object.getPrototypeOf(t)},tr(r)}function Ie(r,e){return Ie=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(n,a){return n.__proto__=a,n},Ie(r,e)}function Tn(){if(typeof Reflect>"u"||!Reflect.construct||Reflect.construct.sham)return!1;if(typeof Proxy=="function")return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){})),!0}catch{return!1}}function He(r,e,t){return Tn()?He=Reflect.construct.bind():He=function(a,l,s){var o=[null];o.push.apply(o,l);var u=Function.bind.apply(a,o),m=new u;return s&&Ie(m,s.prototype),m},He.apply(null,arguments)}function Bn(r){return Function.toString.call(r).indexOf("[native code]")!==-1}function nr(r){var e=typeof Map=="function"?new Map:void 0;return nr=function(n){if(n===null||!Bn(n))return n;if(typeof n!="function")throw new TypeError("Super expression must either be null or a function");if(typeof e<"u"){if(e.has(n))return e.get(n);e.set(n,a)}function a(){return He(n,arguments,tr(this).constructor)}return a.prototype=Object.create(n.prototype,{constructor:{value:a,enumerable:!1,writable:!0,configurable:!0}}),Ie(a,n)},nr(r)}var Vn=/%[sdj%]/g,Wn=function(){};function ir(r){if(!r||!r.length)return null;var e={};return r.forEach(function(t){var n=t.field;e[n]=e[n]||[],e[n].push(t)}),e}function re(r){for(var e=arguments.length,t=new Array(e>1?e-1:0),n=1;n<e;n++)t[n-1]=arguments[n];var a=0,l=t.length;if(typeof r=="function")return r.apply(null,t);if(typeof r=="string"){var s=r.replace(Vn,function(o){if(o==="%%")return"%";if(a>=l)return o;switch(o){case"%s":return String(t[a++]);case"%d":return Number(t[a++]);case"%j":try{return JSON.stringify(t[a++])}catch{return"[Circular]"}break;default:return o}});return s}return r}function jn(r){return r==="string"||r==="url"||r==="hex"||r==="email"||r==="date"||r==="pattern"}function H(r,e){return!!(r==null||e==="array"&&Array.isArray(r)&&!r.length||jn(e)&&typeof r=="string"&&!r)}function Dn(r,e,t){var n=[],a=0,l=r.length;function s(o){n.push.apply(n,o||[]),a++,a===l&&t(n)}r.forEach(function(o){e(o,s)})}function xr(r,e,t){var n=0,a=r.length;function l(s){if(s&&s.length){t(s);return}var o=n;n=n+1,o<a?e(r[o],l):t([])}l([])}function Hn(r){var e=[];return Object.keys(r).forEach(function(t){e.push.apply(e,r[t]||[])}),e}var wr=(function(r){Ln(e,r);function e(t,n){var a;return a=r.call(this,"Async Validation Error")||this,a.errors=t,a.fields=n,a}return e})(nr(Error));function Nn(r,e,t,n,a){if(e.first){var l=new Promise(function(x,C){var f=function(v){return n(v),v.length?C(new wr(v,ir(v))):x(a)},h=Hn(r);xr(h,t,f)});return l.catch(function(x){return x}),l}var s=e.firstFields===!0?Object.keys(r):e.firstFields||[],o=Object.keys(r),u=o.length,m=0,c=[],g=new Promise(function(x,C){var f=function(w){if(c.push.apply(c,w),m++,m===u)return n(c),c.length?C(new wr(c,ir(c))):x(a)};o.length||(n(c),x(a)),o.forEach(function(h){var w=r[h];s.indexOf(h)!==-1?xr(w,t,f):Dn(w,t,f)})});return g.catch(function(x){return x}),g}function Kn(r){return!!(r&&r.message!==void 0)}function Un(r,e){for(var t=r,n=0;n<e.length;n++){if(t==null)return t;t=t[e[n]]}return t}function Cr(r,e){return function(t){var n;return r.fullFields?n=Un(e,r.fullFields):n=e[t.field||r.fullField],Kn(t)?(t.field=t.field||r.fullField,t.fieldValue=n,t):{message:typeof t=="function"?t():t,fieldValue:n,field:t.field||r.fullField}}}function Sr(r,e){if(e){for(var t in e)if(e.hasOwnProperty(t)){var n=e[t];typeof n=="object"&&typeof r[t]=="object"?r[t]=be({},r[t],n):r[t]=n}}return r}var Lr=function(e,t,n,a,l,s){e.required&&(!n.hasOwnProperty(e.field)||H(t,s||e.type))&&a.push(re(l.messages.required,e.fullField))},Yn=function(e,t,n,a,l){(/^\s+$/.test(t)||t==="")&&a.push(re(l.messages.whitespace,e.fullField))},De,Gn=(function(){if(De)return De;var r="[a-fA-F\\d:]",e=function(k){return k&&k.includeBoundaries?"(?:(?<=\\s|^)(?="+r+")|(?<="+r+")(?=\\s|$))":""},t="(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}",n="[a-fA-F\\d]{1,4}",a=(`
(?:
(?:`+n+":){7}(?:"+n+`|:)|                                    // 1:2:3:4:5:6:7::  1:2:3:4:5:6:7:8
(?:`+n+":){6}(?:"+t+"|:"+n+`|:)|                             // 1:2:3:4:5:6::    1:2:3:4:5:6::8   1:2:3:4:5:6::8  1:2:3:4:5:6::1.2.3.4
(?:`+n+":){5}(?::"+t+"|(?::"+n+`){1,2}|:)|                   // 1:2:3:4:5::      1:2:3:4:5::7:8   1:2:3:4:5::8    1:2:3:4:5::7:1.2.3.4
(?:`+n+":){4}(?:(?::"+n+"){0,1}:"+t+"|(?::"+n+`){1,3}|:)| // 1:2:3:4::        1:2:3:4::6:7:8   1:2:3:4::8      1:2:3:4::6:7:1.2.3.4
(?:`+n+":){3}(?:(?::"+n+"){0,2}:"+t+"|(?::"+n+`){1,4}|:)| // 1:2:3::          1:2:3::5:6:7:8   1:2:3::8        1:2:3::5:6:7:1.2.3.4
(?:`+n+":){2}(?:(?::"+n+"){0,3}:"+t+"|(?::"+n+`){1,5}|:)| // 1:2::            1:2::4:5:6:7:8   1:2::8          1:2::4:5:6:7:1.2.3.4
(?:`+n+":){1}(?:(?::"+n+"){0,4}:"+t+"|(?::"+n+`){1,6}|:)| // 1::              1::3:4:5:6:7:8   1::8            1::3:4:5:6:7:1.2.3.4
(?::(?:(?::`+n+"){0,5}:"+t+"|(?::"+n+`){1,7}|:))             // ::2:3:4:5:6:7:8  ::2:3:4:5:6:7:8  ::8             ::1.2.3.4
)(?:%[0-9a-zA-Z]{1,})?                                             // %eth0            %1
`).replace(/\s*\/\/.*$/gm,"").replace(/\n/g,"").trim(),l=new RegExp("(?:^"+t+"$)|(?:^"+a+"$)"),s=new RegExp("^"+t+"$"),o=new RegExp("^"+a+"$"),u=function(k){return k&&k.exact?l:new RegExp("(?:"+e(k)+t+e(k)+")|(?:"+e(k)+a+e(k)+")","g")};u.v4=function(b){return b&&b.exact?s:new RegExp(""+e(b)+t+e(b),"g")},u.v6=function(b){return b&&b.exact?o:new RegExp(""+e(b)+a+e(b),"g")};var m="(?:(?:[a-z]+:)?//)",c="(?:\\S+(?::\\S*)?@)?",g=u.v4().source,x=u.v6().source,C="(?:(?:[a-z\\u00a1-\\uffff0-9][-_]*)*[a-z\\u00a1-\\uffff0-9]+)",f="(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*",h="(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))",w="(?::\\d{2,5})?",v='(?:[/?#][^\\s"]*)?',L="(?:"+m+"|www\\.)"+c+"(?:localhost|"+g+"|"+x+"|"+C+f+h+")"+w+v;return De=new RegExp("(?:^"+L+"$)","i"),De}),kr={email:/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+\.)+[a-zA-Z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]{2,}))$/,hex:/^#?([a-f0-9]{6}|[a-f0-9]{3})$/i},Ee={integer:function(e){return Ee.number(e)&&parseInt(e,10)===e},float:function(e){return Ee.number(e)&&!Ee.integer(e)},array:function(e){return Array.isArray(e)},regexp:function(e){if(e instanceof RegExp)return!0;try{return!!new RegExp(e)}catch{return!1}},date:function(e){return typeof e.getTime=="function"&&typeof e.getMonth=="function"&&typeof e.getYear=="function"&&!isNaN(e.getTime())},number:function(e){return isNaN(e)?!1:typeof e=="number"},object:function(e){return typeof e=="object"&&!Ee.array(e)},method:function(e){return typeof e=="function"},email:function(e){return typeof e=="string"&&e.length<=320&&!!e.match(kr.email)},url:function(e){return typeof e=="string"&&e.length<=2048&&!!e.match(Gn())},hex:function(e){return typeof e=="string"&&!!e.match(kr.hex)}},Zn=function(e,t,n,a,l){if(e.required&&t===void 0){Lr(e,t,n,a,l);return}var s=["integer","float","array","regexp","object","method","email","number","date","url","hex"],o=e.type;s.indexOf(o)>-1?Ee[o](t)||a.push(re(l.messages.types[o],e.fullField,e.type)):o&&typeof t!==e.type&&a.push(re(l.messages.types[o],e.fullField,e.type))},Xn=function(e,t,n,a,l){var s=typeof e.len=="number",o=typeof e.min=="number",u=typeof e.max=="number",m=/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,c=t,g=null,x=typeof t=="number",C=typeof t=="string",f=Array.isArray(t);if(x?g="number":C?g="string":f&&(g="array"),!g)return!1;f&&(c=t.length),C&&(c=t.replace(m,"_").length),s?c!==e.len&&a.push(re(l.messages[g].len,e.fullField,e.len)):o&&!u&&c<e.min?a.push(re(l.messages[g].min,e.fullField,e.min)):u&&!o&&c>e.max?a.push(re(l.messages[g].max,e.fullField,e.max)):o&&u&&(c<e.min||c>e.max)&&a.push(re(l.messages[g].range,e.fullField,e.min,e.max))},ke="enum",Jn=function(e,t,n,a,l){e[ke]=Array.isArray(e[ke])?e[ke]:[],e[ke].indexOf(t)===-1&&a.push(re(l.messages[ke],e.fullField,e[ke].join(", ")))},Qn=function(e,t,n,a,l){if(e.pattern){if(e.pattern instanceof RegExp)e.pattern.lastIndex=0,e.pattern.test(t)||a.push(re(l.messages.pattern.mismatch,e.fullField,t,e.pattern));else if(typeof e.pattern=="string"){var s=new RegExp(e.pattern);s.test(t)||a.push(re(l.messages.pattern.mismatch,e.fullField,t,e.pattern))}}},F={required:Lr,whitespace:Yn,type:Zn,range:Xn,enum:Jn,pattern:Qn},ei=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t,"string")&&!e.required)return n();F.required(e,t,a,s,l,"string"),H(t,"string")||(F.type(e,t,a,s,l),F.range(e,t,a,s,l),F.pattern(e,t,a,s,l),e.whitespace===!0&&F.whitespace(e,t,a,s,l))}n(s)},ri=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&F.type(e,t,a,s,l)}n(s)},ti=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(t===""&&(t=void 0),H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&(F.type(e,t,a,s,l),F.range(e,t,a,s,l))}n(s)},ni=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&F.type(e,t,a,s,l)}n(s)},ii=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),H(t)||F.type(e,t,a,s,l)}n(s)},ai=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&(F.type(e,t,a,s,l),F.range(e,t,a,s,l))}n(s)},oi=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&(F.type(e,t,a,s,l),F.range(e,t,a,s,l))}n(s)},li=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(t==null&&!e.required)return n();F.required(e,t,a,s,l,"array"),t!=null&&(F.type(e,t,a,s,l),F.range(e,t,a,s,l))}n(s)},si=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&F.type(e,t,a,s,l)}n(s)},di="enum",ui=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l),t!==void 0&&F[di](e,t,a,s,l)}n(s)},ci=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t,"string")&&!e.required)return n();F.required(e,t,a,s,l),H(t,"string")||F.pattern(e,t,a,s,l)}n(s)},fi=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t,"date")&&!e.required)return n();if(F.required(e,t,a,s,l),!H(t,"date")){var u;t instanceof Date?u=t:u=new Date(t),F.type(e,u,a,s,l),u&&F.range(e,u.getTime(),a,s,l)}}n(s)},hi=function(e,t,n,a,l){var s=[],o=Array.isArray(t)?"array":typeof t;F.required(e,t,a,s,l,o),n(s)},er=function(e,t,n,a,l){var s=e.type,o=[],u=e.required||!e.required&&a.hasOwnProperty(e.field);if(u){if(H(t,s)&&!e.required)return n();F.required(e,t,a,o,l,s),H(t,s)||F.type(e,t,a,o,l)}n(o)},gi=function(e,t,n,a,l){var s=[],o=e.required||!e.required&&a.hasOwnProperty(e.field);if(o){if(H(t)&&!e.required)return n();F.required(e,t,a,s,l)}n(s)},Me={string:ei,method:ri,number:ti,boolean:ni,regexp:ii,integer:ai,float:oi,array:li,object:si,enum:ui,pattern:ci,date:fi,url:er,hex:er,email:er,required:hi,any:gi};function ar(){return{default:"Validation error on field %s",required:"%s is required",enum:"%s must be one of %s",whitespace:"%s cannot be empty",date:{format:"%s date %s is invalid for format %s",parse:"%s date could not be parsed, %s is invalid ",invalid:"%s date %s is invalid"},types:{string:"%s is not a %s",method:"%s is not a %s (function)",array:"%s is not an %s",object:"%s is not an %s",number:"%s is not a %s",date:"%s is not a %s",boolean:"%s is not a %s",integer:"%s is not an %s",float:"%s is not a %s",regexp:"%s is not a valid %s",email:"%s is not a valid %s",url:"%s is not a valid %s",hex:"%s is not a valid %s"},string:{len:"%s must be exactly %s characters",min:"%s must be at least %s characters",max:"%s cannot be longer than %s characters",range:"%s must be between %s and %s characters"},number:{len:"%s must equal %s",min:"%s cannot be less than %s",max:"%s cannot be greater than %s",range:"%s must be between %s and %s"},array:{len:"%s must be exactly %s in length",min:"%s cannot be less than %s in length",max:"%s cannot be greater than %s in length",range:"%s must be between %s and %s in length"},pattern:{mismatch:"%s value %s does not match pattern %s"},clone:function(){var e=JSON.parse(JSON.stringify(this));return e.clone=this.clone,e}}}var or=ar(),Fe=(function(){function r(t){this.rules=null,this._messages=or,this.define(t)}var e=r.prototype;return e.define=function(n){var a=this;if(!n)throw new Error("Cannot configure a schema with no rules");if(typeof n!="object"||Array.isArray(n))throw new Error("Rules must be an object");this.rules={},Object.keys(n).forEach(function(l){var s=n[l];a.rules[l]=Array.isArray(s)?s:[s]})},e.messages=function(n){return n&&(this._messages=Sr(ar(),n)),this._messages},e.validate=function(n,a,l){var s=this;a===void 0&&(a={}),l===void 0&&(l=function(){});var o=n,u=a,m=l;if(typeof u=="function"&&(m=u,u={}),!this.rules||Object.keys(this.rules).length===0)return m&&m(null,o),Promise.resolve(o);function c(h){var w=[],v={};function L(k){if(Array.isArray(k)){var R;w=(R=w).concat.apply(R,k)}else w.push(k)}for(var b=0;b<h.length;b++)L(h[b]);w.length?(v=ir(w),m(w,v)):m(null,o)}if(u.messages){var g=this.messages();g===or&&(g=ar()),Sr(g,u.messages),u.messages=g}else u.messages=this.messages();var x={},C=u.keys||Object.keys(this.rules);C.forEach(function(h){var w=s.rules[h],v=o[h];w.forEach(function(L){var b=L;typeof b.transform=="function"&&(o===n&&(o=be({},o)),v=o[h]=b.transform(v)),typeof b=="function"?b={validator:b}:b=be({},b),b.validator=s.getValidationMethod(b),b.validator&&(b.field=h,b.fullField=b.fullField||h,b.type=s.getType(b),x[h]=x[h]||[],x[h].push({rule:b,value:v,source:o,field:h}))})});var f={};return Nn(x,u,function(h,w){var v=h.rule,L=(v.type==="object"||v.type==="array")&&(typeof v.fields=="object"||typeof v.defaultField=="object");L=L&&(v.required||!v.required&&h.value),v.field=h.field;function b(M,J){return be({},J,{fullField:v.fullField+"."+M,fullFields:v.fullFields?[].concat(v.fullFields,[M]):[M]})}function k(M){M===void 0&&(M=[]);var J=Array.isArray(M)?M:[M];!u.suppressWarning&&J.length&&r.warning("async-validator:",J),J.length&&v.message!==void 0&&(J=[].concat(v.message));var W=J.map(Cr(v,o));if(u.first&&W.length)return f[v.field]=1,w(W);if(!L)w(W);else{if(v.required&&!h.value)return v.message!==void 0?W=[].concat(v.message).map(Cr(v,o)):u.error&&(W=[u.error(v,re(u.messages.required,v.field))]),w(W);var Y={};v.defaultField&&Object.keys(h.value).map(function(N){Y[N]=v.defaultField}),Y=be({},Y,h.rule.fields);var G={};Object.keys(Y).forEach(function(N){var T=Y[N],fe=Array.isArray(T)?T:[T];G[N]=fe.map(b.bind(null,N))});var te=new r(G);te.messages(u.messages),h.rule.options&&(h.rule.options.messages=u.messages,h.rule.options.error=u.error),te.validate(h.value,h.rule.options||u,function(N){var T=[];W&&W.length&&T.push.apply(T,W),N&&N.length&&T.push.apply(T,N),w(T.length?T:null)})}}var R;if(v.asyncValidator)R=v.asyncValidator(v,h.value,k,h.source,u);else if(v.validator){try{R=v.validator(v,h.value,k,h.source,u)}catch(M){console.error?.(M),u.suppressValidatorError||setTimeout(function(){throw M},0),k(M.message)}R===!0?k():R===!1?k(typeof v.message=="function"?v.message(v.fullField||v.field):v.message||(v.fullField||v.field)+" fails"):R instanceof Array?k(R):R instanceof Error&&k(R.message)}R&&R.then&&R.then(function(){return k()},function(M){return k(M)})},function(h){c(h)},o)},e.getType=function(n){if(n.type===void 0&&n.pattern instanceof RegExp&&(n.type="pattern"),typeof n.validator!="function"&&n.type&&!Me.hasOwnProperty(n.type))throw new Error(re("Unknown rule type %s",n.type));return n.type||"string"},e.getValidationMethod=function(n){if(typeof n.validator=="function")return n.validator;var a=Object.keys(n),l=a.indexOf("message");return l!==-1&&a.splice(l,1),a.length===1&&a[0]==="required"?Me.required:Me[this.getType(n)]||void 0},r})();Fe.register=function(e,t){if(typeof t!="function")throw new Error("Cannot register a validator by type, validator is not a function");Me[e]=t};Fe.warning=Wn;Fe.messages=or;Fe.validators=Me;const{cubicBezierEaseInOut:Fr}=fn;function vi({name:r="fade-down",fromOffset:e="-4px",enterDuration:t=".3s",leaveDuration:n=".3s",enterCubicBezier:a=Fr,leaveCubicBezier:l=Fr}={}){return[V(`&.${r}-transition-enter-from, &.${r}-transition-leave-to`,{opacity:0,transform:`translateY(${e})`}),V(`&.${r}-transition-enter-to, &.${r}-transition-leave-from`,{opacity:1,transform:"translateY(0)"}),V(`&.${r}-transition-leave-active`,{transition:`opacity ${n} ${l}, transform ${n} ${l}`}),V(`&.${r}-transition-enter-active`,{transition:`opacity ${t} ${a}, transform ${t} ${a}`})]}const pi=_("form-item",`
 display: grid;
 line-height: var(--n-line-height);
`,[_("form-item-label",`
 grid-area: label;
 align-items: center;
 line-height: 1.25;
 text-align: var(--n-label-text-align);
 font-size: var(--n-label-font-size);
 min-height: var(--n-label-height);
 padding: var(--n-label-padding);
 color: var(--n-label-text-color);
 transition: color .3s var(--n-bezier);
 box-sizing: border-box;
 font-weight: var(--n-label-font-weight);
 `,[S("asterisk",`
 white-space: nowrap;
 user-select: none;
 -webkit-user-select: none;
 color: var(--n-asterisk-color);
 transition: color .3s var(--n-bezier);
 `),S("asterisk-placeholder",`
 grid-area: mark;
 user-select: none;
 -webkit-user-select: none;
 visibility: hidden; 
 `)]),_("form-item-blank",`
 grid-area: blank;
 min-height: var(--n-blank-height);
 `),B("auto-label-width",[_("form-item-label","white-space: nowrap;")]),B("left-labelled",`
 grid-template-areas:
 "label blank"
 "label feedback";
 grid-template-columns: auto minmax(0, 1fr);
 grid-template-rows: auto 1fr;
 align-items: flex-start;
 `,[_("form-item-label",`
 display: grid;
 grid-template-columns: 1fr auto;
 min-height: var(--n-blank-height);
 height: auto;
 box-sizing: border-box;
 flex-shrink: 0;
 flex-grow: 0;
 `,[B("reverse-columns-space",`
 grid-template-columns: auto 1fr;
 `),B("left-mark",`
 grid-template-areas:
 "mark text"
 ". text";
 `),B("right-mark",`
 grid-template-areas: 
 "text mark"
 "text .";
 `),B("right-hanging-mark",`
 grid-template-areas: 
 "text mark"
 "text .";
 `),S("text",`
 grid-area: text; 
 `),S("asterisk",`
 grid-area: mark; 
 align-self: end;
 `)])]),B("top-labelled",`
 grid-template-areas:
 "label"
 "blank"
 "feedback";
 grid-template-rows: minmax(var(--n-label-height), auto) 1fr;
 grid-template-columns: minmax(0, 100%);
 `,[B("no-label",`
 grid-template-areas:
 "blank"
 "feedback";
 grid-template-rows: 1fr;
 `),_("form-item-label",`
 display: flex;
 align-items: flex-start;
 justify-content: var(--n-label-text-align);
 `)]),_("form-item-blank",`
 box-sizing: border-box;
 display: flex;
 align-items: center;
 position: relative;
 `),_("form-item-feedback-wrapper",`
 grid-area: feedback;
 box-sizing: border-box;
 min-height: var(--n-feedback-height);
 font-size: var(--n-feedback-font-size);
 line-height: 1.25;
 transform-origin: top left;
 `,[V("&:not(:empty)",`
 padding: var(--n-feedback-padding);
 `),_("form-item-feedback",{transition:"color .3s var(--n-bezier)",color:"var(--n-feedback-text-color)"},[B("warning",{color:"var(--n-feedback-text-color-warning)"}),B("error",{color:"var(--n-feedback-text-color-error)"}),vi({fromOffset:"-3px",enterDuration:".3s",leaveDuration:".2s"})])])]);function mi(r){const e=Re(Le,null),{mergedComponentPropsRef:t}=Ue(r);return{mergedSize:O(()=>{var n,a;if(r.size!==void 0)return r.size;if(e?.props.size!==void 0)return e.props.size;const l=(a=(n=t?.value)===null||n===void 0?void 0:n.Form)===null||a===void 0?void 0:a.size;return l||"medium"})}}function bi(r){const e=Re(Le,null),t=O(()=>{const{labelPlacement:f}=r;return f!==void 0?f:e?.props.labelPlacement?e.props.labelPlacement:"top"}),n=O(()=>t.value==="left"&&(r.labelWidth==="auto"||e?.props.labelWidth==="auto")),a=O(()=>{if(t.value==="top")return;const{labelWidth:f}=r;if(f!==void 0&&f!=="auto")return Qe(f);if(n.value){const h=e?.maxChildLabelWidthRef.value;return h!==void 0?Qe(h):void 0}if(e?.props.labelWidth!==void 0)return Qe(e.props.labelWidth)}),l=O(()=>{const{labelAlign:f}=r;if(f)return f;if(e?.props.labelAlign)return e.props.labelAlign}),s=O(()=>{var f;return[(f=r.labelProps)===null||f===void 0?void 0:f.style,r.labelStyle,{width:a.value}]}),o=O(()=>{const{showRequireMark:f}=r;return f!==void 0?f:e?.props.showRequireMark}),u=O(()=>{const{requireMarkPlacement:f}=r;return f!==void 0?f:e?.props.requireMarkPlacement||"right"}),m=I(!1),c=I(!1),g=O(()=>{const{validationStatus:f}=r;if(f!==void 0)return f;if(m.value)return"error";if(c.value)return"warning"}),x=O(()=>{const{showFeedback:f}=r;return f!==void 0?f:e?.props.showFeedback!==void 0?e.props.showFeedback:!0}),C=O(()=>{const{showLabel:f}=r;return f!==void 0?f:e?.props.showLabel!==void 0?e.props.showLabel:!0});return{validationErrored:m,validationWarned:c,mergedLabelStyle:s,mergedLabelPlacement:t,mergedLabelAlign:l,mergedShowRequireMark:o,mergedRequireMarkPlacement:u,mergedValidationStatus:g,mergedShowFeedback:x,mergedShowLabel:C,isAutoLabelWidth:n}}function yi(r){const e=Re(Le,null),t=O(()=>{const{rulePath:s}=r;if(s!==void 0)return s;const{path:o}=r;if(o!==void 0)return o}),n=O(()=>{const s=[],{rule:o}=r;if(o!==void 0&&(Array.isArray(o)?s.push(...o):s.push(o)),e){const{rules:u}=e.props,{value:m}=t;if(u!==void 0&&m!==void 0){const c=Or(u,m);c!==void 0&&(Array.isArray(c)?s.push(...c):s.push(c))}}return s}),a=O(()=>n.value.some(s=>s.required)),l=O(()=>a.value||r.required);return{mergedRules:n,mergedRequired:l}}var Rr=function(r,e,t,n){function a(l){return l instanceof t?l:new t(function(s){s(l)})}return new(t||(t=Promise))(function(l,s){function o(c){try{m(n.next(c))}catch(g){s(g)}}function u(c){try{m(n.throw(c))}catch(g){s(g)}}function m(c){c.done?l(c.value):a(c.value).then(o,u)}m((n=n.apply(r,e||[])).next())})};const xi=Object.assign(Object.assign({},_e.props),{label:String,labelWidth:[Number,String],labelStyle:[String,Object],labelAlign:String,labelPlacement:String,path:String,first:Boolean,rulePath:String,required:Boolean,showRequireMark:{type:Boolean,default:void 0},requireMarkPlacement:String,showFeedback:{type:Boolean,default:void 0},rule:[Object,Array],size:String,ignorePathChange:Boolean,validationStatus:String,feedback:String,feedbackClass:String,feedbackStyle:[String,Object],showLabel:{type:Boolean,default:void 0},labelProps:Object,contentClass:String,contentStyle:[String,Object]});function _r(r,e){return(...t)=>{try{const n=r(...t);return!e&&(typeof n=="boolean"||n instanceof Error||Array.isArray(n))||n?.then?n:(n===void 0||br("form-item/validate",`You return a ${typeof n} typed value in the validator method, which is not recommended. Please use ${e?"`Promise`":"`boolean`, `Error` or `Promise`"} typed value instead.`),!0)}catch(n){br("form-item/validate","An error is catched in the validation, so the validation won't be done. Your callback in `validate` method of `n-form` or `n-form-item` won't be called in this validation."),console.error(n);return}}}const Ri=se({name:"FormItem",props:xi,slots:Object,setup(r){mn(Ir,"formItems",me(r,"path"));const{mergedClsPrefixRef:e,inlineThemeDisabled:t}=Ue(r),n=Re(Le,null),a=mi(r),l=bi(r),{validationErrored:s,validationWarned:o}=l,{mergedRequired:u,mergedRules:m}=yi(r),{mergedSize:c}=a,{mergedLabelPlacement:g,mergedLabelAlign:x,mergedRequireMarkPlacement:C}=l,f=I([]),h=I(mr()),w=I(null),v=n?me(n.props,"disabled"):I(!1),L=_e("Form","-form-item",pi,qr,r,e);qe(me(r,"path"),()=>{r.ignorePathChange||k()});function b(){if(!l.isAutoLabelWidth.value)return;const P=w.value;if(P!==null){const D=P.style.whiteSpace;P.style.whiteSpace="nowrap",P.style.width="",n?.deriveMaxChildLabelWidth(Number(getComputedStyle(P).width.slice(0,-2))),P.style.whiteSpace=D}}function k(){f.value=[],s.value=!1,o.value=!1,r.feedback&&(h.value=mr())}const R=(...P)=>Rr(this,[...P],void 0,function*(D=null,Q=()=>!0,j={suppressWarning:!0}){const{path:Z}=r;j?j.first||(j.first=r.first):j={};const{value:ae}=m,oe=n?Or(n.props.model,Z||""):void 0,de={},ue={},ie=(D?ae.filter(A=>Array.isArray(A.trigger)?A.trigger.includes(D):A.trigger===D):ae).filter(Q).map((A,K)=>{const q=Object.assign({},A);if(q.validator&&(q.validator=_r(q.validator,!1)),q.asyncValidator&&(q.asyncValidator=_r(q.asyncValidator,!0)),q.renderMessage){const Ce=`__renderMessage__${K}`;ue[Ce]=q.message,q.message=Ce,de[Ce]=q.renderMessage}return q}),ee=ie.filter(A=>A.level!=="warning"),le=ie.filter(A=>A.level==="warning"),X={valid:!0,errors:void 0,warnings:void 0};if(!ie.length)return X;const ce=Z??"__n_no_path__",ye=new Fe({[ce]:ee}),xe=new Fe({[ce]:le}),{validateMessages:he}=n?.props||{};he&&(ye.messages(he),xe.messages(he));const we=A=>{f.value=A.map(K=>{const q=K?.message||"";return{key:q,render:()=>q.startsWith("__renderMessage__")?de[q]():q}}),A.forEach(K=>{var q;!((q=K.message)===null||q===void 0)&&q.startsWith("__renderMessage__")&&(K.message=ue[K.message])})};if(ee.length){const A=yield new Promise(K=>{ye.validate({[ce]:oe},j,K)});A?.length&&(X.valid=!1,X.errors=A,we(A))}if(le.length&&!X.errors){const A=yield new Promise(K=>{xe.validate({[ce]:oe},j,K)});A?.length&&(we(A),X.warnings=A)}return!X.errors&&!X.warnings?k():(s.value=!!X.errors,o.value=!!X.warnings),X});function M(){R("blur")}function J(){R("change")}function W(){R("focus")}function Y(){R("input")}function G(P,D){return Rr(this,void 0,void 0,function*(){let Q,j,Z,ae;return typeof P=="string"?(Q=P,j=D):P!==null&&typeof P=="object"&&(Q=P.trigger,j=P.callback,Z=P.shouldRuleBeApplied,ae=P.options),yield new Promise((oe,de)=>{R(Q,Z,ae).then(({valid:ue,errors:ie,warnings:ee})=>{ue?(j&&j(void 0,{warnings:ee}),oe({warnings:ee})):(j&&j(ie,{warnings:ee}),de(ie))})})})}Ke(gn,{path:me(r,"path"),disabled:v,mergedSize:a.mergedSize,mergedValidationStatus:l.mergedValidationStatus,restoreValidation:k,handleContentBlur:M,handleContentChange:J,handleContentFocus:W,handleContentInput:Y});const te={validate:G,restoreValidation:k,internalValidate:R,invalidateLabelWidth:b};Ar(b);const N=O(()=>{var P;const{value:D}=c,{value:Q}=g,j=Q==="top"?"vertical":"horizontal",{common:{cubicBezierEaseInOut:Z},self:{labelTextColor:ae,asteriskColor:oe,lineHeight:de,feedbackTextColor:ue,feedbackTextColorWarning:ie,feedbackTextColorError:ee,feedbackPadding:le,labelFontWeight:X,[ne("labelHeight",D)]:ce,[ne("blankHeight",D)]:ye,[ne("feedbackFontSize",D)]:xe,[ne("feedbackHeight",D)]:he,[ne("labelPadding",j)]:we,[ne("labelTextAlign",j)]:A,[ne(ne("labelFontSize",Q),D)]:K}}=L.value;let q=(P=x.value)!==null&&P!==void 0?P:A;return Q==="top"&&(q=q==="right"?"flex-end":"flex-start"),{"--n-bezier":Z,"--n-line-height":de,"--n-blank-height":ye,"--n-label-font-size":K,"--n-label-text-align":q,"--n-label-height":ce,"--n-label-padding":we,"--n-label-font-weight":X,"--n-asterisk-color":oe,"--n-label-text-color":ae,"--n-feedback-padding":le,"--n-feedback-font-size":xe,"--n-feedback-height":he,"--n-feedback-text-color":ue,"--n-feedback-text-color-warning":ie,"--n-feedback-text-color-error":ee}}),T=t?Er("form-item",O(()=>{var P;return`${c.value[0]}${g.value[0]}${((P=x.value)===null||P===void 0?void 0:P[0])||""}`}),N,r):void 0,fe=O(()=>g.value==="left"&&C.value==="left"&&x.value==="left");return Object.assign(Object.assign(Object.assign(Object.assign({labelElementRef:w,mergedClsPrefix:e,mergedRequired:u,feedbackId:h,renderExplains:f,reverseColSpace:fe},l),a),te),{cssVars:t?void 0:N,themeClass:T?.themeClass,onRender:T?.onRender})},render(){const{$slots:r,mergedClsPrefix:e,mergedShowLabel:t,mergedShowRequireMark:n,mergedRequireMarkPlacement:a,onRender:l}=this,s=n!==void 0?n:this.mergedRequired;l?.();const o=()=>{const u=this.$slots.label?this.$slots.label():this.label;if(!u)return null;const m=p("span",{class:`${e}-form-item-label__text`},u),c=s?p("span",{class:`${e}-form-item-label__asterisk`},a!=="left"?" *":"* "):a==="right-hanging"&&p("span",{class:`${e}-form-item-label__asterisk-placeholder`}," *"),{labelProps:g}=this;return p("label",Object.assign({},g,{class:[g?.class,`${e}-form-item-label`,`${e}-form-item-label--${a}-mark`,this.reverseColSpace&&`${e}-form-item-label--reverse-columns-space`],style:this.mergedLabelStyle,ref:"labelElementRef"}),a==="left"?[c,m]:[m,c])};return p("div",{class:[`${e}-form-item`,this.themeClass,`${e}-form-item--${this.mergedSize}-size`,`${e}-form-item--${this.mergedLabelPlacement}-labelled`,this.isAutoLabelWidth&&`${e}-form-item--auto-label-width`,!t&&`${e}-form-item--no-label`],style:this.cssVars},t&&o(),p("div",{class:[`${e}-form-item-blank`,this.contentClass,this.mergedValidationStatus&&`${e}-form-item-blank--${this.mergedValidationStatus}`],style:this.contentStyle},r),this.mergedShowFeedback?p("div",{key:this.feedbackId,style:this.feedbackStyle,class:[`${e}-form-item-feedback-wrapper`,this.feedbackClass]},p(hn,{name:"fade-down-transition",mode:"out-in"},{default:()=>{const{mergedValidationStatus:u}=this;return Ae(r.feedback,m=>{var c;const{feedback:g}=this,x=m||g?p("div",{key:"__feedback__",class:`${e}-form-item-feedback__line`},m||g):this.renderExplains.length?(c=this.renderExplains)===null||c===void 0?void 0:c.map(({key:C,render:f})=>p("div",{key:C,class:`${e}-form-item-feedback__line`},f())):null;return x?u==="warning"?p("div",{key:"controlled-warning",class:`${e}-form-item-feedback ${e}-form-item-feedback--warning`},x):u==="error"?p("div",{key:"controlled-error",class:`${e}-form-item-feedback ${e}-form-item-feedback--error`},x):u==="success"?p("div",{key:"controlled-success",class:`${e}-form-item-feedback ${e}-form-item-feedback--success`},x):p("div",{key:"controlled-default",class:`${e}-form-item-feedback`},x):null})}})):null)}});export{ki as _,Ri as a,Fi as b,Rn as i};
