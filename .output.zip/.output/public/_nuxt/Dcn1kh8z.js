const t=(e,r="/img/")=>new URL(`${r}${e}`,import.meta.url).href;export{t as g};
