import{a0 as de,w as ie,P as be,ah as d,o as m,p as n,s as S,r as y,ak as ue,ao as he,ap as ke,$ as fe,bf as ve,e as me,aR as pe,an as xe,bs as ge,b5 as B,bw as Ce,bt as _e,bE as K,bA as we,bF as ze,E as U,O as ye,u as V,Q as H,bm as Re,_ as Se,bG as De,bz as Me,aV as $e,K as Ne,H as T,Z as D,bM as N,b3 as Te,aZ as Be,W as P,B as Ie}from"./O-zoPhqF.js";import{b as Ve,a as Fe,_ as Ue}from"./B7mCMK7D.js";import{u as He}from"./bM5Y2li9.js";import"./Bsz9TjBg.js";const Pe={sizeSmall:"14px",sizeMedium:"16px",sizeLarge:"18px",labelPadding:"0 8px",labelFontWeight:"400"};function Ke(r){const{baseColor:a,inputColorDisabled:i,cardColor:b,modalColor:t,popoverColor:c,textColorDisabled:u,borderColor:h,primaryColor:k,textColor2:l,fontSizeSmall:s,fontSizeMedium:o,fontSizeLarge:p,borderRadiusSmall:g,lineHeight:C}=r;return Object.assign(Object.assign({},Pe),{labelLineHeight:C,fontSizeSmall:s,fontSizeMedium:o,fontSizeLarge:p,borderRadius:g,color:a,colorChecked:k,colorDisabled:i,colorDisabledChecked:i,colorTableHeader:b,colorTableHeaderModal:t,colorTableHeaderPopover:c,checkMarkColor:a,checkMarkColorDisabled:u,checkMarkColorDisabledChecked:u,border:`1px solid ${h}`,borderDisabled:`1px solid ${h}`,borderDisabledChecked:`1px solid ${h}`,borderChecked:`1px solid ${k}`,borderFocus:`1px solid ${k}`,boxShadowFocus:`0 0 0 2px ${ie(k,{alpha:.3})}`,textColor:l,textColorDisabled:u})}const je={common:de,self:Ke},Ee=be("n-checkbox-group"),Oe=()=>d("svg",{viewBox:"0 0 64 64",class:"check-icon"},d("path",{d:"M50.42,16.76L22.34,39.45l-8.1-11.46c-1.12-1.58-3.3-1.96-4.88-0.84c-1.58,1.12-1.95,3.3-0.84,4.88l10.26,14.51  c0.56,0.79,1.42,1.31,2.38,1.45c0.16,0.02,0.32,0.03,0.48,0.03c0.8,0,1.57-0.27,2.2-0.78l30.99-25.03c1.5-1.21,1.74-3.42,0.52-4.92  C54.13,15.78,51.93,15.55,50.42,16.76z"})),Le=()=>d("svg",{viewBox:"0 0 100 100",class:"line-icon"},d("path",{d:"M80.2,55.5H21.4c-2.8,0-5.1-2.5-5.1-5.5l0,0c0-3,2.3-5.5,5.1-5.5h58.7c2.8,0,5.1,2.5,5.1,5.5l0,0C85.2,53.1,82.9,55.5,80.2,55.5z"})),Ae=m([n("checkbox",`
 font-size: var(--n-font-size);
 outline: none;
 cursor: pointer;
 display: inline-flex;
 flex-wrap: nowrap;
 align-items: flex-start;
 word-break: break-word;
 line-height: var(--n-size);
 --n-merged-color-table: var(--n-color-table);
 `,[S("show-label","line-height: var(--n-label-line-height);"),m("&:hover",[n("checkbox-box",[y("border","border: var(--n-border-checked);")])]),m("&:focus:not(:active)",[n("checkbox-box",[y("border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),S("inside-table",[n("checkbox-box",`
 background-color: var(--n-merged-color-table);
 `)]),S("checked",[n("checkbox-box",`
 background-color: var(--n-color-checked);
 `,[n("checkbox-icon",[m(".check-icon",`
 opacity: 1;
 transform: scale(1);
 `)])])]),S("indeterminate",[n("checkbox-box",[n("checkbox-icon",[m(".check-icon",`
 opacity: 0;
 transform: scale(.5);
 `),m(".line-icon",`
 opacity: 1;
 transform: scale(1);
 `)])])]),S("checked, indeterminate",[m("&:focus:not(:active)",[n("checkbox-box",[y("border",`
 border: var(--n-border-checked);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),n("checkbox-box",`
 background-color: var(--n-color-checked);
 border-left: 0;
 border-top: 0;
 `,[y("border",{border:"var(--n-border-checked)"})])]),S("disabled",{cursor:"not-allowed"},[S("checked",[n("checkbox-box",`
 background-color: var(--n-color-disabled-checked);
 `,[y("border",{border:"var(--n-border-disabled-checked)"}),n("checkbox-icon",[m(".check-icon, .line-icon",{fill:"var(--n-check-mark-color-disabled-checked)"})])])]),n("checkbox-box",`
 background-color: var(--n-color-disabled);
 `,[y("border",`
 border: var(--n-border-disabled);
 `),n("checkbox-icon",[m(".check-icon, .line-icon",`
 fill: var(--n-check-mark-color-disabled);
 `)])]),y("label",`
 color: var(--n-text-color-disabled);
 `)]),n("checkbox-box-wrapper",`
 position: relative;
 width: var(--n-size);
 flex-shrink: 0;
 flex-grow: 0;
 user-select: none;
 -webkit-user-select: none;
 `),n("checkbox-box",`
 position: absolute;
 left: 0;
 top: 50%;
 transform: translateY(-50%);
 height: var(--n-size);
 width: var(--n-size);
 display: inline-block;
 box-sizing: border-box;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color 0.3s var(--n-bezier);
 `,[y("border",`
 transition:
 border-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 border-radius: inherit;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border: var(--n-border);
 `),n("checkbox-icon",`
 display: flex;
 align-items: center;
 justify-content: center;
 position: absolute;
 left: 1px;
 right: 1px;
 top: 1px;
 bottom: 1px;
 `,[m(".check-icon, .line-icon",`
 width: 100%;
 fill: var(--n-check-mark-color);
 opacity: 0;
 transform: scale(0.5);
 transform-origin: center;
 transition:
 fill 0.3s var(--n-bezier),
 transform 0.3s var(--n-bezier),
 opacity 0.3s var(--n-bezier),
 border-color 0.3s var(--n-bezier);
 `),ue({left:"1px",top:"1px"})])]),y("label",`
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 padding: var(--n-label-padding);
 font-weight: var(--n-label-font-weight);
 `,[m("&:empty",{display:"none"})])]),he(n("checkbox",`
 --n-merged-color-table: var(--n-color-table-modal);
 `)),ke(n("checkbox",`
 --n-merged-color-table: var(--n-color-table-popover);
 `))]),We=Object.assign(Object.assign({},K.props),{size:String,checked:{type:[Boolean,String,Number],default:void 0},defaultChecked:{type:[Boolean,String,Number],default:!1},value:[String,Number],disabled:{type:Boolean,default:void 0},indeterminate:Boolean,label:String,focusable:{type:Boolean,default:!0},checkedValue:{type:[Boolean,String,Number],default:!0},uncheckedValue:{type:[Boolean,String,Number],default:!1},"onUpdate:checked":[Function,Array],onUpdateChecked:[Function,Array],privateInsideTable:Boolean,onChange:[Function,Array]}),qe=fe({name:"Checkbox",props:We,setup(r){const a=xe(Ee,null),i=B(null),{mergedClsPrefixRef:b,inlineThemeDisabled:t,mergedRtlRef:c,mergedComponentPropsRef:u}=ge(r),h=B(r.defaultChecked),k=Re(r,"checked"),l=He(k,h),s=Ce(()=>{if(a){const e=a.valueSetRef.value;return e&&r.value!==void 0?e.has(r.value):!1}else return l.value===r.checkedValue}),o=_e(r,{mergedSize(e){var f,v;const{size:x}=r;if(x!==void 0)return x;if(a){const{value:z}=a.mergedSizeRef;if(z!==void 0)return z}if(e){const{mergedSize:z}=e;if(z!==void 0)return z.value}const w=(v=(f=u?.value)===null||f===void 0?void 0:f.Checkbox)===null||v===void 0?void 0:v.size;return w||"medium"},mergedDisabled(e){const{disabled:f}=r;if(f!==void 0)return f;if(a){if(a.disabledRef.value)return!0;const{maxRef:{value:v},checkedCountRef:x}=a;if(v!==void 0&&x.value>=v&&!s.value)return!0;const{minRef:{value:w}}=a;if(w!==void 0&&x.value<=w&&s.value)return!0}return e?e.disabled.value:!1}}),{mergedDisabledRef:p,mergedSizeRef:g}=o,C=K("Checkbox","-checkbox",Ae,je,r,b);function _(e){if(a&&r.value!==void 0)a.toggleCheckbox(!s.value,r.value);else{const{onChange:f,"onUpdate:checked":v,onUpdateChecked:x}=r,{nTriggerFormInput:w,nTriggerFormChange:z}=o,$=s.value?r.uncheckedValue:r.checkedValue;v&&V(v,$,e),x&&V(x,$,e),f&&V(f,$,e),w(),z(),h.value=$}}function I(e){p.value||_(e)}function R(e){if(!p.value)switch(e.key){case" ":case"Enter":_(e)}}function j(e){e.key===" "&&e.preventDefault()}const E={focus:()=>{var e;(e=i.value)===null||e===void 0||e.focus()},blur:()=>{var e;(e=i.value)===null||e===void 0||e.blur()}},O=we("Checkbox",c,b),F=U(()=>{const{value:e}=g,{common:{cubicBezierEaseInOut:f},self:{borderRadius:v,color:x,colorChecked:w,colorDisabled:z,colorTableHeader:$,colorTableHeaderModal:L,colorTableHeaderPopover:A,checkMarkColor:W,checkMarkColorDisabled:q,border:G,borderFocus:Z,borderDisabled:Q,borderChecked:Y,boxShadowFocus:J,textColor:X,textColorDisabled:ee,checkMarkColorDisabledChecked:oe,colorDisabledChecked:re,borderDisabledChecked:ae,labelPadding:le,labelLineHeight:ne,labelFontWeight:ce,[H("fontSize",e)]:se,[H("size",e)]:te}}=C.value;return{"--n-label-line-height":ne,"--n-label-font-weight":ce,"--n-size":te,"--n-bezier":f,"--n-border-radius":v,"--n-border":G,"--n-border-checked":Y,"--n-border-focus":Z,"--n-border-disabled":Q,"--n-border-disabled-checked":ae,"--n-box-shadow-focus":J,"--n-color":x,"--n-color-checked":w,"--n-color-table":$,"--n-color-table-modal":L,"--n-color-table-popover":A,"--n-color-disabled":z,"--n-color-disabled-checked":re,"--n-text-color":X,"--n-text-color-disabled":ee,"--n-check-mark-color":W,"--n-check-mark-color-disabled":q,"--n-check-mark-color-disabled-checked":oe,"--n-font-size":se,"--n-label-padding":le}}),M=t?ze("checkbox",U(()=>g.value[0]),F,r):void 0;return Object.assign(o,E,{rtlEnabled:O,selfRef:i,mergedClsPrefix:b,mergedDisabled:p,renderedChecked:s,mergedTheme:C,labelId:ye(),handleClick:I,handleKeyUp:R,handleKeyDown:j,cssVars:t?void 0:F,themeClass:M?.themeClass,onRender:M?.onRender})},render(){var r;const{$slots:a,renderedChecked:i,mergedDisabled:b,indeterminate:t,privateInsideTable:c,cssVars:u,labelId:h,label:k,mergedClsPrefix:l,focusable:s,handleKeyUp:o,handleKeyDown:p,handleClick:g}=this;(r=this.onRender)===null||r===void 0||r.call(this);const C=ve(a.default,_=>k||_?d("span",{class:`${l}-checkbox__label`,id:h},k||_):null);return d("div",{ref:"selfRef",class:[`${l}-checkbox`,this.themeClass,this.rtlEnabled&&`${l}-checkbox--rtl`,i&&`${l}-checkbox--checked`,b&&`${l}-checkbox--disabled`,t&&`${l}-checkbox--indeterminate`,c&&`${l}-checkbox--inside-table`,C&&`${l}-checkbox--show-label`],tabindex:b||!s?void 0:0,role:"checkbox","aria-checked":t?"mixed":i,"aria-labelledby":h,style:u,onKeyup:o,onKeydown:p,onClick:g,onMousedown:()=>{pe("selectstart",window,_=>{_.preventDefault()},{once:!0})}},d("div",{class:`${l}-checkbox-box-wrapper`}," ",d("div",{class:`${l}-checkbox-box`},d(me,null,{default:()=>this.indeterminate?d("div",{key:"indeterminate",class:`${l}-checkbox-icon`},Le()):d("div",{key:"check",class:`${l}-checkbox-icon`},Oe())}),d("div",{class:`${l}-checkbox-box__border`}))),C)}}),Ge={class:"login-page"},Ze={class:"login-card"},Qe={class:"is_checked"},Ye={class:"btn-box"},Je={__name:"login",setup(r){const a=De(),i=Me(),b=B(null),t=B(!1),c=Te({userName:"",password:""}),u={userName:{required:!0,message:"请输入你的狗名😯",trigger:["input"]},password:{required:!0,message:"请输入相同的小秘",trigger:["input"]}},h=()=>{a.checkedInfo?(t.value=a.checkedInfo.isChecked,c.userName=a.checkedInfo.userName,c.password=a.checkedInfo.password):t.value=!1},k=()=>{let s=null;return t.value&&(s={isChecked:!0,userName:c.userName,password:c.password}),s},l=()=>{b.value?.validate(async s=>{if(s)console.log("请输入你的狗名和密码");else try{const o=await $fetch("/api/login",{method:"POST",body:c});o.code===200?(a.login(o.data),a.updateCheckedInfo(k()),i.push("/")):console.log(o.msg)}catch{console.log("请求失败")}})};return $e(()=>{h()}),(s,o)=>{const p=Ue,g=Fe,C=qe,_=Ie,I=Ve;return Be(),Ne("div",Ge,[T("div",Ze,[o[5]||(o[5]=T("h2",{class:"logo"},"六人组 · 我们的网站",-1)),D(I,{ref_key:"formRef",ref:b,model:c,rules:u,"label-placement":"left","label-width":"auto","require-mark-placement":"left",class:"login-form"},{default:N(()=>[D(g,{label:"账号：",path:"userName"},{default:N(()=>[D(p,{value:c.userName,"onUpdate:value":o[0]||(o[0]=R=>c.userName=R),placeholder:"请输入账号",size:"large"},null,8,["value"])]),_:1}),D(g,{label:"密码：",path:"password"},{default:N(()=>[D(p,{value:c.password,"onUpdate:value":o[1]||(o[1]=R=>c.password=R),type:"password",placeholder:"请输入密码",size:"large","show-password-on":"mousedown"},null,8,["value"]),T("div",Qe,[D(C,{checked:t.value,"onUpdate:checked":o[2]||(o[2]=R=>t.value=R)},{default:N(()=>[...o[3]||(o[3]=[P("记住账号密码",-1)])]),_:1},8,["checked"])])]),_:1}),T("div",Ye,[D(_,{type:"primary",size:"large",block:"",onClick:l},{default:N(()=>[...o[4]||(o[4]=[P(" 登 录 ",-1)])]),_:1})])]),_:1},8,["model"])])])}}},ao=Se(Je,[["__scopeId","data-v-a5df1093"]]);export{ao as default};
