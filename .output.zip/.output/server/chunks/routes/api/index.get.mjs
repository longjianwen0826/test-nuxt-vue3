import { b as defineEventHandler } from '../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineEventHandler(() => {
  const filePath = path.join(process.cwd(), "server/data/userList.json");
  if (!fs.existsSync(filePath)) {
    return { code: 200, data: [] };
  }
  try {
    let data = fs.readFileSync(filePath, "utf-8");
    let list = JSON.parse(data) || [];
    return { code: 200, data: list };
  } catch (err) {
    return { code: 200, data: [] };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
