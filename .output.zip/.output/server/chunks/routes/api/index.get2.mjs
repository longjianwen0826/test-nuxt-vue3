import { b as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineEventHandler(() => {
  return {
    code: 200,
    data: {
      title: "\u6211\u4EEC\u516D\u4E2A\uFF0C\u4ECE\u5C0F\u73A9\u5230\u5927\u7684\u53D1\u5C0F",
      content: "\u6211\u4EEC\u4ECE\u5C0F\u4E00\u8D77\u957F\u5927\uFF0C\u4E00\u8D77\u75AF\u3001\u4E00\u8D77\u95F9\u3001\u4E00\u8D77\u4E92\u635F\uFF0C\u4E5F\u4E00\u8D77\u625B\u4E8B\u3002\u5435\u4E0D\u6563\uFF0C\u9A82\u4E0D\u8D70\uFF0C\u65F6\u95F4\u8D8A\u4E45\uFF0C\u611F\u60C5\u8D8A\u6DF1\u3002\u8FD9\u662F\u6211\u4EEC\u6700\u73CD\u8D35\u7684\u9752\u6625\uFF0C\u6700\u7EAF\u7CB9\u7684\u53CB\u60C5\u3002"
    }
  };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
