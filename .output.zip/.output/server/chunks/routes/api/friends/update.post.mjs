import { b as defineEventHandler, A as readBody } from '../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const update_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { id, ...data } = body;
  if (!id) return { code: 400, msg: "\u7F3A\u5C11ID" };
  if (!data.name) return { code: 400, msg: "\u59D3\u540D\u4E0D\u80FD\u4E3A\u7A7A" };
  const filePath = path.join(process.cwd(), "server/data/userList.json");
  const list = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  const index = list.findIndex((i) => i.id == id);
  if (index === -1) return { code: 404, msg: "\u597D\u53CB\u4E0D\u5B58\u5728" };
  list[index] = { ...list[index], ...data, id };
  fs.writeFileSync(filePath, JSON.stringify(list, null, 2));
  return { code: 200, msg: "\u66F4\u65B0\u6210\u529F" };
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
