import { b as defineEventHandler, A as readBody } from '../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const add_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const data = body;
  if (!data.name) {
    return { code: 400, msg: "\u59D3\u540D name \u4E3A\u5FC5\u586B\u9879" };
  }
  const filePath = path.join(process.cwd(), "server/data/userList.json");
  let list = [];
  if (fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, "utf-8");
    list = JSON.parse(content) || [];
  }
  list.push({
    ...data,
    id: Date.now()
    // 自动生成唯一ID
  });
  fs.writeFileSync(filePath, JSON.stringify(list, null, 2));
  return { code: 200, msg: "\u6DFB\u52A0\u597D\u53CB\u6210\u529F\uFF01" };
});

export { add_post as default };
//# sourceMappingURL=add.post.mjs.map
