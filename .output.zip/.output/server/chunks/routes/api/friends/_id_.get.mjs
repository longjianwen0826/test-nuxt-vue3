import { b as defineEventHandler, r as getRouterParam } from '../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const _id__get = defineEventHandler((event) => {
  const id = getRouterParam(event, "id");
  const filePath = path.join(process.cwd(), "server/data/userList.json");
  if (!fs.existsSync(filePath)) {
    return { code: 404, msg: "\u65E0\u6570\u636E" };
  }
  const list = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  const item = list.find((i) => i.id == id);
  if (!item) return { code: 404, msg: "\u597D\u53CB\u4E0D\u5B58\u5728" };
  return { code: 200, data: item };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
