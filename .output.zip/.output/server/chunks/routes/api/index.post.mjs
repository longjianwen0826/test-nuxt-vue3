import { b as defineEventHandler, A as readBody } from '../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { userName, password } = body;
    if (!userName || !password) {
      return {
        code: 400,
        msg: "\u59D3\u540D\u548CID\u4E0D\u80FD\u4E3A\u7A7A",
        data: null
      };
    }
    const filePath = path.join(process.cwd(), "server/data/userList.json");
    if (!fs.existsSync(filePath)) {
      return {
        code: 404,
        msg: "\u6682\u65E0\u7528\u6237\u6570\u636E",
        data: null
      };
    }
    const userList = JSON.parse(fs.readFileSync(filePath, "utf-8")) || [];
    const findUser = userList.find(
      (user) => user.userName === userName && user.password === password
    );
    if (!findUser) {
      return {
        code: 401,
        msg: "\u8D26\u53F7\u6216\u5BC6\u7801\u4E0D\u6B63\u786E",
        data: null
      };
    }
    return {
      code: 200,
      msg: "\u767B\u5F55\u6210\u529F",
      data: findUser
    };
  } catch (err) {
    return {
      code: 500,
      msg: "\u670D\u52A1\u5668\u5F02\u5E38",
      data: null
    };
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
